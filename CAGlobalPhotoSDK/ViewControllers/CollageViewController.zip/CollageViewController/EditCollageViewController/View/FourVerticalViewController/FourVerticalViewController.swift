//
//  FourVerticalViewController.swift
//  Snaptouch_Polaroid
//
//  Created by maximess120 on 26/02/18.
//  Copyright © 2018 maximess142. All rights reserved.
//

import UIKit 


class FourVerticalViewController: BaseViewController {
    
    @IBOutlet weak var imageScrollViewBottomRight: ZoomImageView!
    @IBOutlet weak var imageScrollViewBottomLeft: ZoomImageView!
    @IBOutlet weak var imageScrollViewTopRight: ZoomImageView!
    @IBOutlet weak var imageScrollViewTopLeft: ZoomImageView!
    @IBOutlet weak var collageBackgroundView: UIView!
    
    @IBOutlet weak var topRightView: UIView!
    @IBOutlet weak var topLeftView: UIView!
    @IBOutlet weak var bottomLeftView: UIView!
    @IBOutlet weak var bottomRightView: UIView!
    
    @IBOutlet weak var topRightViewConstraintWidth: NSLayoutConstraint!
    @IBOutlet weak var topRightViewConstraintHeight: NSLayoutConstraint!
    @IBOutlet weak var topLeftViewConstraintWidth: NSLayoutConstraint!
    @IBOutlet weak var topLeftViewConstraintHeight: NSLayoutConstraint!
    
    @IBOutlet weak var bottomLeftViewConstraintWidth: NSLayoutConstraint!
    @IBOutlet weak var bottomLeftViewConstraintHeight: NSLayoutConstraint!
    
    @IBOutlet weak var bottomRightViewConstraintWidth: NSLayoutConstraint!
    @IBOutlet weak var bottomRightViewConstraintHeight: NSLayoutConstraint!
    
    @IBOutlet weak var sepratorTopIndicatorConstraintTrailing: NSLayoutConstraint!
    @IBOutlet weak var sepratorTopIndicatorView: UIView!
    
    @IBOutlet weak var sepratorBottomIndicatorConstraintTrailing: NSLayoutConstraint!
    @IBOutlet weak var sepratorBottomIndicatorView: UIView!
    
    @IBOutlet weak var sepratorLeftIndicatorConstraintBottom: NSLayoutConstraint!
    @IBOutlet weak var sepratorLeftIndicatorView: UIView!
    
    @IBOutlet weak var sepratorRightIndicatorConstraintBottom: NSLayoutConstraint!
    @IBOutlet weak var sepratorRightIndicatorView: UIView!
    
    
    
    var isSepratorAvailable = false
    var selImgArray = [UIImage]()
    var selectedTilesNumber = Int()
    var editViewModel = CAEditViewModel()

    
    fileprivate func loadUI() {
        configureTapGestures()
        setInitialConstraints()
        assignImagesToImageScrollViews()
        configureSeparators()
        addBordersToCollageViews()
        initLongPressGesture()
    }

    private func configureTapGestures() {
        let tapGestures = [topLeftView, topRightView, bottomLeftView, bottomRightView].map { view in
            return UITapGestureRecognizer(target: self, action: #selector(FourVerticalViewController.singleTapGestureRecognizer(_:)))
        }
        
        tapGestures.forEach { gesture in
            gesture.numberOfTapsRequired = 1
        }
        
        for (index, gesture) in tapGestures.enumerated() {
            [topLeftView, topRightView, bottomLeftView, bottomRightView][index].addGestureRecognizer(gesture)
        }
    }
    
    private func assignImagesToImageScrollViews() {
        for i in 0..<selImgArray.count {
            if i < imageScrollViewArray.count {
                imageScrollViewArray[i].zoomMode = .fill
                imageScrollViewArray[i].image = selImgArray[i]
            }
        }
    }

    private func configureSeparators() {
        let separators = [sepratorTopIndicatorView, sepratorBottomIndicatorView, sepratorLeftIndicatorView, sepratorRightIndicatorView]
        
        for separator in separators {
            separator?.layer.cornerRadius = separatorIndicatorCornerRadius
            separator?.layer.borderWidth = 0.5
            separator?.layer.borderColor = UIColor.lightGray.cgColor
        }
    }

    private func addBordersToCollageViews() {
        let collageViews = [collageBackgroundView, topLeftView, topRightView, bottomLeftView, bottomRightView]
        
        for view in collageViews {
            view?.layer.borderWidth = collageTilesBorderWidth
            view?.layer.borderColor = UIColor.clear.cgColor
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        loadUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        registerForNotifications()
        addSeparatorsToTiles()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.updateUIConstraints()
        }
    }

    private func registerForNotifications() {
        let notificationNames: [NSNotification.Name: Selector] = [
            .init("FourVerticalVCMirror"): #selector(applyMirrorEffect(_:)),
            .init("FourVerticalVCFlip"): #selector(applyFlipEffect(_:)),
            .init("FourVerticalVCBorder"): #selector(applyBorderEffect(_:)),
            .init("FourVerticalVCSaveImg"): #selector(saveCollageImage(_:)),
            .init("FourVerticalVCRotate"): #selector(applyRotateEffect(_:))
        ]
        
        for (name, selector) in notificationNames {
            NotificationCenter.default.addObserver(self, selector: selector, name: name, object: nil)
        }
    }

    private func updateUIConstraints() {
        setInitialConstraints()
        updateTilesFrame()
        removeSeparatorsFromTiles()
    }

    
    override func viewDidDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
    }
    
    func initLongPressGesture() {
        addLongPressGesture(to: topLeftView, action: #selector(longPressGestureRecognized1(_:)))
        addLongPressGesture(to: topRightView, action: #selector(longPressGestureRecognized2(_:)))
        addLongPressGesture(to: bottomLeftView, action: #selector(longPressGestureRecognized3(_:)))
        addLongPressGesture(to: bottomRightView, action: #selector(longPressGestureRecognized4(_:)))
    }

    private func addLongPressGesture(to view: UIView, action: Selector) {
        let longPressGesture = UILongPressGestureRecognizer(target: self, action: action)
        view.addGestureRecognizer(longPressGesture)
    }

    
    func removeSeparatorsFromTiles() {
        guard separatorColor == UIColor.clear else {
            return
        }
        
        updateTilesFrame()
        
        for subview in collageBackgroundView.subviews {
            if subview is SeparatorView {
                subview.removeFromSuperview()
            }
        }
    }

    
    func setInitialConstraints() {
        let tilesWidth = collageBackgroundView.frame.size.width / 2
        let tilesHeight = collageBackgroundView.frame.size.height / 2

        [topRightView, topLeftView, bottomLeftView, bottomRightView].forEach { view in
            view.widthAnchor.constraint(equalToConstant: tilesWidth).isActive = true
            view.heightAnchor.constraint(equalToConstant: tilesHeight).isActive = true
            view.layoutIfNeeded()
        }
    }

    
    @objc func longPressGestureRecognized1(_ gestureRecognizer: UIGestureRecognizer) {
        
        let longPress = gestureRecognizer as! UILongPressGestureRecognizer
        let state = longPress.state
        let locationInView = longPress.location(in: self.collageBackgroundView)
        
        
        struct My {
            static var cellSnapshot : UIView? = nil
            static var cellIsAnimating : Bool = false
            static var cellNeedToShow : Bool = false
        }
        
        
        switch state {
        case UIGestureRecognizer.State.began:
            
            
            My.cellSnapshot  = self.snapshotOfCell(topLeftView)
            
            var center = topLeftView.center
            My.cellSnapshot!.center = center
            My.cellSnapshot!.alpha = 0.0
            self.collageBackgroundView.addSubview(My.cellSnapshot!)
            
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellIsAnimating = true
                My.cellSnapshot!.center = center
                My.cellSnapshot!.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
                My.cellSnapshot!.alpha = 0.98
                // cell?.alpha = 0.0
            }, completion: { (finished) -> Void in
                if finished {
                    My.cellIsAnimating = false
                    if My.cellNeedToShow {
                        My.cellNeedToShow = false
                        UIView.animate(withDuration: 0.25, animations: { () -> Void in
                            //cell?.alpha = 1
                        })
                    } else {
                        //cell?.isHidden = true
                    }
                }
            })
            
            
        case UIGestureRecognizer.State.changed:
            //print("change")
            
            if My.cellSnapshot != nil {
                var center = My.cellSnapshot!.center
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellSnapshot!.center = center
                
            
                if My.cellSnapshot!.center.x > (self.topRightView.center.x - (self.topRightView.frame.width/3)) && My.cellSnapshot!.center.x < (self.topRightView.center.x + (self.topRightView.frame.width/3)) && My.cellSnapshot!.center.y > (self.topRightView.center.y - (self.topRightView.frame.height/3)) && My.cellSnapshot!.center.y < (self.topRightView.center.y + (self.topRightView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewTopRight.image
                    let img2 = self.imageScrollViewTopLeft.image
                    
                    self.imageScrollViewTopRight.image = img2
                        
                    self.imageScrollViewTopLeft.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.bottomLeftView.center.x - (self.bottomLeftView.frame.width/3)) && My.cellSnapshot!.center.x < (self.bottomLeftView.center.x + (self.bottomLeftView.frame.width/3)) && My.cellSnapshot!.center.y > (self.bottomLeftView.center.y - (self.bottomLeftView.frame.height/3)) && My.cellSnapshot!.center.y < (self.bottomLeftView.center.y + (self.bottomLeftView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottomLeft.image
                    let img2 = self.imageScrollViewTopLeft.image
                    
                    self.imageScrollViewBottomLeft.image = img2
                    self.imageScrollViewTopLeft.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.bottomRightView.center.x - (self.bottomRightView.frame.width/3)) && My.cellSnapshot!.center.x < (self.bottomRightView.center.x + (self.bottomRightView.frame.width/3)) && My.cellSnapshot!.center.y > (self.bottomRightView.center.y - (self.bottomRightView.frame.height/3)) && My.cellSnapshot!.center.y < (self.bottomRightView.center.y + (self.bottomRightView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottomRight.image
                    let img2 = self.imageScrollViewTopLeft.image
                    
                    self.imageScrollViewBottomRight.image = img2
                    self.imageScrollViewTopLeft.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                
            }
            
        default:
            //print("default")
            if My.cellSnapshot != nil {
                
                My.cellSnapshot!.removeFromSuperview()
                My.cellSnapshot = nil
            }
            
        }
        
    }
    
    @objc func longPressGestureRecognized2(_ gestureRecognizer: UIGestureRecognizer) {
        
        let longPress = gestureRecognizer as! UILongPressGestureRecognizer
        let state = longPress.state
        let locationInView = longPress.location(in: self.collageBackgroundView)
        
        
        struct My {
            static var cellSnapshot : UIView? = nil
            static var cellIsAnimating : Bool = false
            static var cellNeedToShow : Bool = false
        }
        
        
        switch state {
        case UIGestureRecognizer.State.began:
            
            
            My.cellSnapshot  = self.snapshotOfCell(topRightView)
            
            var center = topRightView.center
            My.cellSnapshot!.center = center
            My.cellSnapshot!.alpha = 0.0
            self.collageBackgroundView.addSubview(My.cellSnapshot!)
            
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellIsAnimating = true
                My.cellSnapshot!.center = center
                My.cellSnapshot!.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
                My.cellSnapshot!.alpha = 0.98
                // cell?.alpha = 0.0
            }, completion: { (finished) -> Void in
                if finished {
                    My.cellIsAnimating = false
                    if My.cellNeedToShow {
                        My.cellNeedToShow = false
                        UIView.animate(withDuration: 0.25, animations: { () -> Void in
                            //cell?.alpha = 1
                        })
                    } else {
                        //cell?.isHidden = true
                    }
                }
            })
            
            
        case UIGestureRecognizer.State.changed:
            //print("change")
            
            if My.cellSnapshot != nil {
                var center = My.cellSnapshot!.center
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellSnapshot!.center = center
                
                
                if My.cellSnapshot!.center.x > (self.topLeftView.center.x - (self.topLeftView.frame.width/3)) && My.cellSnapshot!.center.x < (self.topLeftView.center.x + (self.topLeftView.frame.width/3)) && My.cellSnapshot!.center.y > (self.topLeftView.center.y - (self.topLeftView.frame.height/3)) && My.cellSnapshot!.center.y < (self.topLeftView.center.y + (self.topLeftView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewTopRight.image
                    let img2 = self.imageScrollViewTopLeft.image
                    
                    self.imageScrollViewTopRight.image = img2
                    
                    self.imageScrollViewTopLeft.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.bottomLeftView.center.x - (self.bottomLeftView.frame.width/3)) && My.cellSnapshot!.center.x < (self.bottomLeftView.center.x + (self.bottomLeftView.frame.width/3)) && My.cellSnapshot!.center.y > (self.bottomLeftView.center.y - (self.bottomLeftView.frame.height/3)) && My.cellSnapshot!.center.y < (self.bottomLeftView.center.y + (self.bottomLeftView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottomLeft.image
                    let img2 = self.imageScrollViewTopRight.image
                    
                    self.imageScrollViewBottomLeft.image = img2
                    self.imageScrollViewTopRight.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.bottomRightView.center.x - (self.bottomRightView.frame.width/3)) && My.cellSnapshot!.center.x < (self.bottomRightView.center.x + (self.bottomRightView.frame.width/3)) && My.cellSnapshot!.center.y > (self.bottomRightView.center.y - (self.bottomRightView.frame.height/3)) && My.cellSnapshot!.center.y < (self.bottomRightView.center.y + (self.bottomRightView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottomRight.image
                    let img2 = self.imageScrollViewTopRight.image
                    
                    self.imageScrollViewBottomRight.image = img2
                    self.imageScrollViewTopRight.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                
            }
            
        default:
            //print("default")
            if My.cellSnapshot != nil {
                
                My.cellSnapshot!.removeFromSuperview()
                My.cellSnapshot = nil
            }
            
        }
        
    }
    
    @objc func longPressGestureRecognized3(_ gestureRecognizer: UIGestureRecognizer) {
        
        let longPress = gestureRecognizer as! UILongPressGestureRecognizer
        let state = longPress.state
        let locationInView = longPress.location(in: self.collageBackgroundView)
        struct My {
            static var cellSnapshot : UIView? = nil
            static var cellIsAnimating : Bool = false
            static var cellNeedToShow : Bool = false
        }
        
        
        switch state {
        case UIGestureRecognizer.State.began:
            
            
            My.cellSnapshot  = self.snapshotOfCell(bottomLeftView)
            
            var center = bottomLeftView.center
            My.cellSnapshot!.center = center
            My.cellSnapshot!.alpha = 0.0
            self.collageBackgroundView.addSubview(My.cellSnapshot!)
            
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellIsAnimating = true
                My.cellSnapshot!.center = center
                My.cellSnapshot!.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
                My.cellSnapshot!.alpha = 0.98
                // cell?.alpha = 0.0
            }, completion: { (finished) -> Void in
                if finished {
                    My.cellIsAnimating = false
                    if My.cellNeedToShow {
                        My.cellNeedToShow = false
                        UIView.animate(withDuration: 0.25, animations: { () -> Void in
                            //cell?.alpha = 1
                        })
                    } else {
                        //cell?.isHidden = true
                    }
                }
            })
            
            
        case UIGestureRecognizer.State.changed:
            //print("change")
            
            if My.cellSnapshot != nil {
                var center = My.cellSnapshot!.center
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellSnapshot!.center = center
                
                
                if My.cellSnapshot!.center.x > (self.topLeftView.center.x - (self.topLeftView.frame.width/3)) && My.cellSnapshot!.center.x < (self.topLeftView.center.x + (self.topLeftView.frame.width/3)) && My.cellSnapshot!.center.y > (self.topLeftView.center.y - (self.topLeftView.frame.height/3)) && My.cellSnapshot!.center.y < (self.topLeftView.center.y + (self.topLeftView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottomLeft.image
                    let img2 = self.imageScrollViewTopLeft.image
                    
                    self.imageScrollViewBottomLeft.image = img2
                    
                    self.imageScrollViewTopLeft.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.topRightView.center.x - (self.topRightView.frame.width/3)) && My.cellSnapshot!.center.x < (self.topRightView.center.x + (self.topRightView.frame.width/3)) && My.cellSnapshot!.center.y > (self.topRightView.center.y - (self.topRightView.frame.height/3)) && My.cellSnapshot!.center.y < (self.topRightView.center.y + (self.topRightView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottomLeft.image
                    let img2 = self.imageScrollViewTopRight.image
                    
                    self.imageScrollViewBottomLeft.image = img2
                    self.imageScrollViewTopRight.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.bottomRightView.center.x - (self.bottomRightView.frame.width/3)) && My.cellSnapshot!.center.x < (self.bottomRightView.center.x + (self.bottomRightView.frame.width/3)) && My.cellSnapshot!.center.y > (self.bottomRightView.center.y - (self.bottomRightView.frame.height/3)) && My.cellSnapshot!.center.y < (self.bottomRightView.center.y + (self.bottomRightView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottomRight.image
                    let img2 = self.imageScrollViewBottomLeft.image
                    
                    self.imageScrollViewBottomRight.image = img2
                    self.imageScrollViewBottomLeft.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                
            }
            
        default:
            //print("default")
            if My.cellSnapshot != nil {
                
                My.cellSnapshot!.removeFromSuperview()
                My.cellSnapshot = nil
            }
            
        }
        
    }
    
    
    @objc func longPressGestureRecognized4(_ gestureRecognizer: UIGestureRecognizer) {
        
        let longPress = gestureRecognizer as! UILongPressGestureRecognizer
        let state = longPress.state
        let locationInView = longPress.location(in: self.collageBackgroundView)
        
        
        struct My {
            static var cellSnapshot : UIView? = nil
            static var cellIsAnimating : Bool = false
            static var cellNeedToShow : Bool = false
        }
        
        
        switch state {
        case UIGestureRecognizer.State.began:
            
            
            My.cellSnapshot  = self.snapshotOfCell(bottomRightView)
            
            var center = bottomRightView.center
            My.cellSnapshot!.center = center
            My.cellSnapshot!.alpha = 0.0
            self.collageBackgroundView.addSubview(My.cellSnapshot!)
            
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellIsAnimating = true
                My.cellSnapshot!.center = center
                My.cellSnapshot!.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
                My.cellSnapshot!.alpha = 0.98
                // cell?.alpha = 0.0
            }, completion: { (finished) -> Void in
                if finished {
                    My.cellIsAnimating = false
                    if My.cellNeedToShow {
                        My.cellNeedToShow = false
                        UIView.animate(withDuration: 0.25, animations: { () -> Void in
                            //cell?.alpha = 1
                        })
                    } else {
                        //cell?.isHidden = true
                    }
                }
            })
            
            
        case UIGestureRecognizer.State.changed:
            //print("change")
            
            if My.cellSnapshot != nil {
                var center = My.cellSnapshot!.center
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellSnapshot!.center = center
                
                
                if My.cellSnapshot!.center.x > (self.topLeftView.center.x - (self.topLeftView.frame.width/3)) && My.cellSnapshot!.center.x < (self.topLeftView.center.x + (self.topLeftView.frame.width/3)) && My.cellSnapshot!.center.y > (self.topLeftView.center.y - (self.topLeftView.frame.height/3)) && My.cellSnapshot!.center.y < (self.topLeftView.center.y + (self.topLeftView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottomRight.image
                    let img2 = self.imageScrollViewTopLeft.image
                    
                    self.imageScrollViewBottomRight.image = img2
                    
                    self.imageScrollViewTopLeft.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.bottomLeftView.center.x - (self.bottomLeftView.frame.width/3)) && My.cellSnapshot!.center.x < (self.bottomLeftView.center.x + (self.bottomLeftView.frame.width/3)) && My.cellSnapshot!.center.y > (self.bottomLeftView.center.y - (self.bottomLeftView.frame.height/3)) && My.cellSnapshot!.center.y < (self.bottomLeftView.center.y + (self.bottomLeftView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottomLeft.image
                    let img2 = self.imageScrollViewBottomRight.image
                    
                    self.imageScrollViewBottomLeft.image = img2
                    self.imageScrollViewBottomRight.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.topRightView.center.x - (self.topRightView.frame.width/3)) && My.cellSnapshot!.center.x < (self.topRightView.center.x + (self.topRightView.frame.width/3)) && My.cellSnapshot!.center.y > (self.topRightView.center.y - (self.topRightView.frame.height/3)) && My.cellSnapshot!.center.y < (self.topRightView.center.y + (self.topRightView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottomRight.image
                    let img2 = self.imageScrollViewTopRight.image
                    
                    self.imageScrollViewBottomRight.image = img2
                    self.imageScrollViewTopRight.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                
            }
            
        default:
            //print("default")
            if My.cellSnapshot != nil {
                
                My.cellSnapshot!.removeFromSuperview()
                My.cellSnapshot = nil
            }
            
        }
        
    }
    
    
    func snapshotOfCell(_ inputView: UIView) -> UIView {
        UIGraphicsBeginImageContextWithOptions(inputView.bounds.size, false, 0.0)
        inputView.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        let cellSnapshot : UIView = UIImageView(image: image)
        cellSnapshot.layer.masksToBounds = false
        cellSnapshot.layer.cornerRadius = 0.0
        cellSnapshot.layer.shadowOffset = CGSize(width: -5.0, height: 0.0)
        cellSnapshot.layer.shadowRadius = 5.0
        cellSnapshot.layer.shadowOpacity = 0.4
        return cellSnapshot
    }
    
    func updateTilesFrame()  {
        
        self.topRightViewConstraintWidth.constant = self.topRightView.frame.size.width
        self.topRightViewConstraintHeight.constant = self.topRightView.frame.size.height
        
        
        self.topLeftViewConstraintWidth.constant = self.topLeftView.frame.size.width
        self.topLeftViewConstraintHeight.constant = self.topLeftView.frame.size.height
        
        self.bottomLeftViewConstraintWidth.constant = self.bottomLeftView.frame.size.width
        self.bottomLeftViewConstraintHeight.constant = self.bottomLeftView.frame.size.height
        
        self.bottomRightViewConstraintWidth.constant = self.bottomRightView.frame.size.width
        self.bottomRightViewConstraintHeight.constant = self.bottomRightView.frame.size.height
        
        
    }
    
    func addSeparatorsToTiles() {
        
        //vertical seprators
        SeparatorView.addSeparatorBetweenViews(separatorType: .vertical, primaryView: topLeftView, secondaryView: topRightView, parentView: self.collageBackgroundView)
        
        
        //Horizantal seprators
        SeparatorView.addSeparatorBetweenViews(separatorType: .horizontal, primaryView: topLeftView, secondaryView: bottomLeftView, parentView: self.collageBackgroundView)
        
        
        
    }
    
    @objc func singleTapGestureRecognizer(_ gestureRecognizer: UIGestureRecognizer) {
        let selectedViewTag = gestureRecognizer.view?.tag
        selectedCollageFrameIndexInEdit = selectedViewTag! - 1
        self.addBorderToSelectedTils(tag:selectedViewTag!)
    }
    
    func addBorderToSelectedTils(tag:Int)  {
        switch tag {
            
        case 1:
            
            self.sepratorTopIndicatorConstraintTrailing.constant = 2
            self.sepratorLeftIndicatorConstraintBottom.constant = 2
            
            if topLeftView.layer.borderColor == collageTilesBorderColor{
                self.removeBorderOfTiles()
                self.removeSeparatorsFromTiles()
                topLeftView.layer.borderColor = UIColor.clear.cgColor
                
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":0])
                
            }else{
                self.removeBorderOfTiles()
                topLeftView.layer.borderColor = collageTilesBorderColor
                
                sepratorTopIndicatorView.isHidden = false
                sepratorLeftIndicatorView.isHidden = false
                if separatorColor == UIColor.clear
                {
                self.removeSeparatorsFromTiles()
                self.addSeparatorsToTiles()
                }
                self.selectedTilesNumber = 1
                
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":1])
            }
            
        case 2:
            
            self.sepratorTopIndicatorConstraintTrailing.constant = 5
            self.sepratorRightIndicatorConstraintBottom.constant = 2
            
            if topRightView.layer.borderColor == collageTilesBorderColor{
                self.removeBorderOfTiles()
                self.removeSeparatorsFromTiles()
                topRightView.layer.borderColor = UIColor.clear.cgColor
                
                
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":0])
                
            }else{
                self.removeBorderOfTiles()
                topRightView.layer.borderColor = collageTilesBorderColor
                sepratorTopIndicatorView.isHidden = false
                sepratorRightIndicatorView.isHidden = false
                if separatorColor == UIColor.clear
                {
                self.removeSeparatorsFromTiles()
                self.addSeparatorsToTiles()
                }
                self.selectedTilesNumber = 2
                
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":1])
            }
            
        case 3:
            
            self.sepratorLeftIndicatorConstraintBottom.constant = 5
            self.sepratorBottomIndicatorConstraintTrailing.constant = 2
            
            if bottomLeftView.layer.borderColor == collageTilesBorderColor{
                self.removeBorderOfTiles()
                self.removeSeparatorsFromTiles()
                bottomLeftView.layer.borderColor = UIColor.clear.cgColor
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":0])
            } else {
                self.removeBorderOfTiles()
                bottomLeftView.layer.borderColor = collageTilesBorderColor
                sepratorBottomIndicatorView.isHidden = false
                sepratorLeftIndicatorView.isHidden = false
                if separatorColor == UIColor.clear {
                    self.removeSeparatorsFromTiles()
                    self.addSeparatorsToTiles()
                }
                self.selectedTilesNumber = 3
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":1])
            }
        case 4:
            self.sepratorBottomIndicatorConstraintTrailing.constant = 5
            self.sepratorRightIndicatorConstraintBottom.constant = 5
            if bottomRightView.layer.borderColor == collageTilesBorderColor{
                self.removeBorderOfTiles()
                self.removeSeparatorsFromTiles()
                bottomRightView.layer.borderColor = UIColor.clear.cgColor
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":0])
            } else {
                self.removeBorderOfTiles()
                bottomRightView.layer.borderColor = collageTilesBorderColor
                sepratorBottomIndicatorView.isHidden = false
                sepratorRightIndicatorView.isHidden = false
                if separatorColor == UIColor.clear {
                    self.removeSeparatorsFromTiles()
                    self.addSeparatorsToTiles()
                }
                self.selectedTilesNumber = 4
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":1])
            }
        default: break
        }
    }
    
    func removeBorderOfTiles()  {
        sepratorTopIndicatorView.isHidden = true
        sepratorBottomIndicatorView.isHidden = true
        sepratorLeftIndicatorView.isHidden = true
        sepratorRightIndicatorView.isHidden = true
        topLeftView.layer.borderColor = UIColor.clear.cgColor
        topRightView.layer.borderColor = UIColor.clear.cgColor
        bottomLeftView.layer.borderColor = UIColor.clear.cgColor
        bottomRightView.layer.borderColor = UIColor.clear.cgColor
        self.selectedTilesNumber = 0
    }
    
    @objc func applyMirrorEffect(_ notification: NSNotification) {
        switch selectedTilesNumber {
        case 1:
            let img = self.imageScrollViewTopLeft.image
            let flippedImage = self.setEffectOn(image:img!, effect:.mirror)
            self.imageScrollViewTopLeft.image = flippedImage
        case 2:
            let img = self.imageScrollViewTopRight.image
            let flippedImage = self.setEffectOn(image:img!, effect:.mirror)
            self.imageScrollViewTopRight.image = flippedImage
        case 3:
            let img = self.imageScrollViewBottomLeft.image
            let flippedImage = self.setEffectOn(image:img!, effect:.mirror)
            self.imageScrollViewBottomLeft.image = flippedImage
        case 4:
            let img = self.imageScrollViewBottomRight.image
            let flippedImage = self.setEffectOn(image:img!, effect:.mirror)
            self.imageScrollViewBottomRight.image = flippedImage
        default: break
        }
    }
    
    @objc func applyFlipEffect(_ notification: NSNotification) {
        switch selectedTilesNumber {
        case 1:
            let img = self.imageScrollViewTopLeft.image
            let flippedImage = self.setEffectOn(image:img!, effect:.flip)
            self.imageScrollViewTopLeft.image = flippedImage
        case 2:
            let img = self.imageScrollViewTopRight.image
            let flippedImage = self.setEffectOn(image:img!, effect:.flip)
            self.imageScrollViewTopRight.image = flippedImage
        case 3:
            let img = self.imageScrollViewBottomLeft.image
            let flippedImage = self.setEffectOn(image:img!, effect:.flip)
            self.imageScrollViewBottomLeft.image =  flippedImage
        case 4:
            let img = self.imageScrollViewBottomRight.image
            let flippedImage = self.setEffectOn(image:img!, effect:.flip)
            self.imageScrollViewBottomRight.image = flippedImage
        default: break
        }
    }
    
    @objc func applyRotateEffect(_ notification: NSNotification) {
        switch selectedTilesNumber {
        case 1:
            let img = self.imageScrollViewTopLeft.image
            let flippedImage = self.setEffectOn(image:img!, effect:.rotate)
            self.imageScrollViewTopLeft.image = flippedImage
        case 2:
            let img = self.imageScrollViewTopRight.image
            let flippedImage = self.setEffectOn(image:img!, effect:.rotate)
            self.imageScrollViewTopRight.image = flippedImage
        case 3:
            let img = self.imageScrollViewBottomLeft.image
            let flippedImage = self.setEffectOn(image:img!, effect:.rotate)
            self.imageScrollViewBottomLeft.image = flippedImage
        case 4:
            let img = self.imageScrollViewBottomRight.image
            let flippedImage = self.setEffectOn(image:img!, effect:.rotate)
            self.imageScrollViewBottomRight.image = flippedImage
        default: break
        }
    }
    
    @objc func applyBorderEffect(_ notification: NSNotification) {
        if separatorColor == UIColor.white{
            separatorColor = UIColor.clear
            collageBackgroundView.layer.borderColor = UIColor.clear.cgColor
            self.removeSeparatorsFromTiles()
            self.addSeparatorsToTiles()
        } else {
            separatorColor = UIColor.white
            collageBackgroundView.layer.borderColor = UIColor.white.cgColor
            self.removeSeparatorsFromTiles()
            self.updateTilesFrame()
            for (view) in self.collageBackgroundView.subviews {
                if view is SeparatorView {
                    view.removeFromSuperview()
                }
            }
            self.addSeparatorsToTiles()
        }
    }
    
    @objc func saveCollageImage(_ notification: NSNotification) {
        self.updateTilesFrame()
        self.removeSeparatorsFromTiles()
        self.removeBorderOfTiles()
        //Crop  image
        let renderer = UIGraphicsImageRenderer(size: self.collageBackgroundView.bounds.size)
        let image = renderer.image { ctx in
            self.collageBackgroundView.drawHierarchy(in: self.collageBackgroundView.bounds, afterScreenUpdates: true)
        }
        if image.size.width != 0 {
            collageImage = image
        }
    }
}

//
//  TwoVerticalViewController.swift
//  Snaptouch_Polaroid
//
//  Created by maximess120 on 20/02/18.
//  Copyright © 2018 maximess142. All rights reserved.
//

import UIKit

class TwoVerticalViewController: BaseViewController {

    @IBOutlet weak var imageScrollViewRight: ZoomImageView!
    @IBOutlet weak var imageScrollViewLeft: ZoomImageView!
    @IBOutlet weak var collageBackgroundView: UIView!
    @IBOutlet weak var rightView: UIView!
    @IBOutlet weak var leftView: UIView!
    @IBOutlet weak var rightViewConstraintWidth: NSLayoutConstraint!
    @IBOutlet weak var leftViewConstraintWidth: NSLayoutConstraint!
    @IBOutlet weak var sepratorIndicatorConstraintTrailing: NSLayoutConstraint!
    @IBOutlet weak var sepratorIndicatorView: UIView!
    var isSepratorAvailable = false
    var selImgArray = [UIImage]()
    var selectedTilesNumber = Int()
    var editViewModel = CAEditViewModel()
    fileprivate func loadUI() {
        imageScrollViewArray = [imageScrollViewLeft,imageScrollViewRight]
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(TwoVerticalViewController.singleTapGestureRecognizer(_:)))
        let tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(TwoVerticalViewController.singleTapGestureRecognizer(_:)))
        tapGesture1.numberOfTapsRequired = 1
        tapGesture2.numberOfTapsRequired = 1
        leftView.addGestureRecognizer(tapGesture1)
        rightView.addGestureRecognizer(tapGesture2)
        self.setInitialConstraints()
        for index in 0..<selImgArray.count {
            if index < imageScrollViewArray.count{
                imageScrollViewArray[index].zoomMode = .fill
                imageScrollViewArray[index].image = selImgArray[index]
            }
        }
        sepratorIndicatorView.layer.cornerRadius = separatorIndicatorCornerRadius
        sepratorIndicatorView.layer.borderWidth = 0.5
        sepratorIndicatorView.layer.borderColor = UIColor.lightGray.cgColor
        collageBackgroundView.layer.borderWidth = collageTilesBorderWidth
        collageBackgroundView.layer.borderColor = UIColor.clear.cgColor
        leftView.layer.borderWidth = collageTilesBorderWidth
        leftView.layer.borderColor = UIColor.clear.cgColor
        rightView.layer.borderWidth = collageTilesBorderWidth
        rightView.layer.borderColor = UIColor.clear.cgColor
        self.initLongPressGesture()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        loadUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        NotificationCenter.default.addObserver(self, selector: #selector(self.applyMirrorEffect(_:)), name: NSNotification.Name(rawValue: "TwoVerticalVCMirror"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.applyFlipEffect(_:)), name: NSNotification.Name(rawValue: "TwoVerticalVCFlip"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.applyBorderEffect(_:)), name: NSNotification.Name(rawValue: "TwoVerticalVCBorder"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.saveCollageImage(_:)), name: NSNotification.Name(rawValue: "TwoVerticalVCSaveImg"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.applyRotateEffect(_:)), name: NSNotification.Name(rawValue: "TwoVerticalVCRotate"), object: nil)
        self.addSepratorsToTiles()
        DispatchQueue.main.asyncAfter(deadline: when) {
            self.setInitialConstraints()
            self.updateTilesFrame()
            self.removeSepratorFromTiles()
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
    }

    func initImages()  {
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(TwoVerticalViewController.singleTapGestureRecognizer(_:)))
        let tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(TwoVerticalViewController.singleTapGestureRecognizer(_:)))
        tapGesture1.numberOfTapsRequired = 1
        tapGesture2.numberOfTapsRequired = 1
        leftView.addGestureRecognizer(tapGesture1)
        rightView.addGestureRecognizer(tapGesture2)
        self.setInitialConstraints()
        for index in 0..<selImgArray.count {
            if index < imageScrollViewArray.count{
                imageScrollViewArray[index].zoomMode = .fill
                imageScrollViewArray[index].image = selImgArray[index]
            }
        }
        sepratorIndicatorView.layer.cornerRadius = separatorIndicatorCornerRadius
        sepratorIndicatorView.layer.borderWidth = 0.5
        sepratorIndicatorView.layer.borderColor = UIColor.lightGray.cgColor
        // add borders to collage background view
        collageBackgroundView.layer.borderWidth = collageTilesBorderWidth
        collageBackgroundView.layer.borderColor = UIColor.clear.cgColor
        // add borders to collage tiles
        leftView.layer.borderWidth = collageTilesBorderWidth
        leftView.layer.borderColor = UIColor.clear.cgColor
        rightView.layer.borderWidth = collageTilesBorderWidth
        rightView.layer.borderColor = UIColor.clear.cgColor
        self.initLongPressGesture()
        self.addSepratorsToTiles()
        DispatchQueue.main.asyncAfter(deadline: when) {
            self.setInitialConstraints()
            self.updateTilesFrame()
            self.removeSepratorFromTiles()
        }
    }
    
    func initLongPressGesture()  {
        let longpress1 = UILongPressGestureRecognizer(target: self, action: #selector(TwoVerticalViewController.longPressGestureRecognized1(_:)))
        leftView.addGestureRecognizer(longpress1)
        let longpress2 = UILongPressGestureRecognizer(target: self, action: #selector(TwoVerticalViewController.longPressGestureRecognized2(_:)))
        rightView.addGestureRecognizer(longpress2)
    }
    
    func removeSepratorFromTiles()  {
        if separatorColor == UIColor.clear {
        self.updateTilesFrame()
            for (view) in self.collageBackgroundView.subviews {
                if view is SeparatorView {
                    view.removeFromSuperview()
                }
            }
        }
    }
    
    func setInitialConstraints()  {
        var tilesWidth = CGFloat()
        tilesWidth = self.collageBackgroundView.frame.size.width / 2
        self.rightViewConstraintWidth.constant = tilesWidth
        self.leftViewConstraintWidth.constant = tilesWidth
        self.rightView.layoutIfNeeded()
        self.leftView.layoutIfNeeded()
    }
    
    func updateTilesFrame()  {
        self.rightViewConstraintWidth.constant = self.rightView.frame.size.width
        self.leftViewConstraintWidth.constant = self.leftView.frame.size.width
    }
    
    func addSepratorsToTiles()  {
        SeparatorView.addSeparatorBetweenViews(separatorType: .vertical, primaryView: leftView, secondaryView: rightView, parentView: self.collageBackgroundView)
    }
    
    @objc func longPressGestureRecognized1(_ gestureRecognizer: UIGestureRecognizer) {
        let longPress = gestureRecognizer as! UILongPressGestureRecognizer
        let state = longPress.state
        let locationInView = longPress.location(in: self.collageBackgroundView)
        struct My {
            static var cellSnapshot : UIView? = nil
            static var cellIsAnimating : Bool = false
            static var cellNeedToShow : Bool = false
        }
        switch state {
        case UIGestureRecognizer.State.began:
            My.cellSnapshot  = self.snapshotOfCell(leftView)
            var center = leftView.center
            My.cellSnapshot!.center = center
            My.cellSnapshot!.alpha = 0.0
            self.collageBackgroundView.addSubview(My.cellSnapshot!)
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellIsAnimating = true
                My.cellSnapshot!.center = center
                My.cellSnapshot!.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
                My.cellSnapshot!.alpha = 0.98
            }, completion: { (finished) -> Void in
                if finished {
                    My.cellIsAnimating = false
                    if My.cellNeedToShow {
                        My.cellNeedToShow = false
                    }
                }
            })
        case UIGestureRecognizer.State.changed:
            if My.cellSnapshot != nil {
                var center = My.cellSnapshot!.center
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellSnapshot!.center = center
                let isXgreater = My.cellSnapshot!.center.x > (self.leftView.center.x - (self.leftView.frame.width/3))
                let isXLess = My.cellSnapshot!.center.x < (self.leftView.center.x + (self.leftView.frame.width/3))
                let isYGreater = My.cellSnapshot!.center.y > (self.leftView.center.y - (self.leftView.frame.height/3))
                let isYless = My.cellSnapshot!.center.y < (self.leftView.center.y + (self.leftView.frame.height/3))
                if isXgreater && isXLess && isYGreater && isYless {
                    let img1 = self.imageScrollViewRight.image
                    let img2 = self.imageScrollViewLeft.image
                    self.imageScrollViewRight.image = img2
                    self.imageScrollViewLeft.image = img1
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
            }
        default:
            if My.cellSnapshot != nil {
                My.cellSnapshot!.removeFromSuperview()
                My.cellSnapshot = nil
            }
        }
    }
    
    @objc func longPressGestureRecognized2(_ gestureRecognizer: UILongPressGestureRecognizer) {
        let longPress = gestureRecognizer
        let state = longPress.state
        let locationInView = longPress.location(in: self.collageBackgroundView)
        struct My {
            static var cellSnapshot : UIView? = nil
            static var cellIsAnimating : Bool = false
            static var cellNeedToShow : Bool = false
        }
        switch state {
        case UIGestureRecognizer.State.began:
            My.cellSnapshot  = self.snapshotOfCell(rightView)
            var center = rightView.center
            My.cellSnapshot!.center = center
            My.cellSnapshot!.alpha = 0.0
            self.collageBackgroundView.addSubview(My.cellSnapshot!)
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                center.y = locationInView.y ?? 0
                center.x = locationInView.x ?? 0
                My.cellIsAnimating = true
                My.cellSnapshot!.center = center
                My.cellSnapshot!.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
                My.cellSnapshot!.alpha = 0.98
            }, completion: { (finished) -> Void in
                if finished {
                    My.cellIsAnimating = false
                    if My.cellNeedToShow {
                        My.cellNeedToShow = false
                    }
                }
            })
        case UIGestureRecognizer.State.changed:
            if My.cellSnapshot != nil {
                var center = My.cellSnapshot!.center
                center.y = locationInView.y ?? 0
                center.x = locationInView.x ?? 0
                My.cellSnapshot!.center = center
                let isXgreater = My.cellSnapshot!.center.x > (self.leftView.center.x - (self.leftView.frame.width/3))
                let isXLess = My.cellSnapshot!.center.x < (self.leftView.center.x + (self.leftView.frame.width/3))
                let isYGreater = My.cellSnapshot!.center.y > (self.leftView.center.y - (self.leftView.frame.height/3))
                let isYless = My.cellSnapshot!.center.y < (self.leftView.center.y + (self.leftView.frame.height/3))
                if isXgreater && isXLess && isYGreater && isYless {
                    let img1 = self.imageScrollViewRight.image
                    let img2 = self.imageScrollViewLeft.image
                    self.imageScrollViewRight.image = img2
                    self.imageScrollViewLeft.image = img1
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
            }
        default:
            if My.cellSnapshot != nil {
                My.cellSnapshot!.removeFromSuperview()
                My.cellSnapshot = nil
            }
        }
    }
    
    func snapshotOfCell(_ inputView: UIView) -> UIView {
        UIGraphicsBeginImageContextWithOptions(inputView.bounds.size, false, 0.0)
        inputView.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        let cellSnapshot : UIView = UIImageView(image: image)
        cellSnapshot.layer.masksToBounds = false
        cellSnapshot.layer.cornerRadius = 0.0
        cellSnapshot.layer.shadowOffset = CGSize(width: -5.0, height: 0.0)
        cellSnapshot.layer.shadowRadius = 5.0
        cellSnapshot.layer.shadowOpacity = 0.4
        return cellSnapshot
    }
    
    @objc func singleTapGestureRecognizer(_ gestureRecognizer: UIGestureRecognizer) {
        let selectedViewTag = gestureRecognizer.view?.tag
        selectedCollageFrameIndexInEdit = selectedViewTag! - 1
        self.addBorderToSelectedTils(tag:selectedViewTag!)
    }
    
    func addBorderToSelectedTils(tag:Int)  {
        switch tag {
        case 1:
            self.sepratorIndicatorConstraintTrailing.constant = 2
            if leftView.layer.borderColor == collageTilesBorderColor{
                self.removeBorderOfTiles()
                self.removeSepratorFromTiles()
                leftView.layer.borderColor = UIColor.clear.cgColor
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":0])
            }else{
                self.removeBorderOfTiles()
                leftView.layer.borderColor = collageTilesBorderColor
                sepratorIndicatorView.isHidden = false
                if separatorColor == UIColor.clear {
                self.removeSepratorFromTiles()
                self.addSepratorsToTiles()
                }
                self.selectedTilesNumber = 1
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":1])
            }
            
        case 2:
            self.sepratorIndicatorConstraintTrailing.constant = 5
            if rightView.layer.borderColor == collageTilesBorderColor{
                self.removeBorderOfTiles()
                self.removeSepratorFromTiles()
                rightView.layer.borderColor = UIColor.clear.cgColor
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":0])
            }else{
                self.removeBorderOfTiles()
                rightView.layer.borderColor = collageTilesBorderColor
                sepratorIndicatorView.isHidden = false
                if separatorColor == UIColor.clear {
                self.removeSepratorFromTiles()
                self.addSepratorsToTiles()
                }
                self.selectedTilesNumber = 2
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":1])
            }
        default:
            self.selectedTilesNumber = 0
        }
    }
    
    func removeBorderOfTiles()  {
        sepratorIndicatorView.isHidden = true
        leftView.layer.borderColor = UIColor.clear.cgColor
        rightView.layer.borderColor = UIColor.clear.cgColor
        self.selectedTilesNumber = 0
    }

    @objc func applyMirrorEffect(_ notification: NSNotification) {
        
        switch selectedTilesNumber {
        case 1:
            let img = self.imageScrollViewLeft.image
            let flippedImage = self.setEffectOn(image:img!, effect:.mirror)
            
            self.imageScrollViewLeft.image = flippedImage
        case 2:
            let img = self.imageScrollViewRight.image
            let flippedImage = self.setEffectOn(image:img!, effect:.mirror)
            
            self.imageScrollViewRight.image = flippedImage
        default: break
        }
    }
    
    @objc func applyFlipEffect(_ notification: NSNotification) {
        switch selectedTilesNumber {
        case 1:
            let img = self.imageScrollViewLeft.image
            let flippedImage = self.setEffectOn(image:img!, effect:.flip)
            self.imageScrollViewLeft.image = flippedImage
        case 2:
            let img = self.imageScrollViewRight.image
            let flippedImage = self.setEffectOn(image:img!, effect:.flip)
            self.imageScrollViewRight.image = flippedImage
        default: break
        }
    }
    
    @objc func applyRotateEffect(_ notification: NSNotification) {
        switch selectedTilesNumber {
        case 1:
            let img = self.imageScrollViewLeft.image
            let flippedImage = self.setEffectOn(image:img!, effect:.rotate)
            self.imageScrollViewLeft.image = flippedImage
        case 2:
            let img = self.imageScrollViewRight.image
            let flippedImage = self.setEffectOn(image:img!, effect:.rotate)
            self.imageScrollViewRight.image = flippedImage
        default: break
        }
    }
    
    @objc func applyBorderEffect(_ notification: NSNotification) {
        if separatorColor == UIColor.white{
            separatorColor = UIColor.clear
            collageBackgroundView.layer.borderColor = UIColor.clear.cgColor
            self.removeSepratorFromTiles()
            self.addSepratorsToTiles()
        } else {
            separatorColor = UIColor.white
            collageBackgroundView.layer.borderColor = UIColor.white.cgColor
            self.removeSepratorFromTiles()
            self.updateTilesFrame()
            for (view) in self.collageBackgroundView.subviews {
                if view is SeparatorView {
                    view.removeFromSuperview()
                }
            }
            self.addSepratorsToTiles()
        }
    }
    
    @objc func saveCollageImage(_ notification: NSNotification) {
        self.updateTilesFrame()
        self.removeSepratorFromTiles()
        self.removeBorderOfTiles()
        let renderer = UIGraphicsImageRenderer(size: self.collageBackgroundView.bounds.size)
        let image = renderer.image { ctx in
            self.collageBackgroundView.drawHierarchy(in: self.collageBackgroundView.bounds, afterScreenUpdates: true)
        }
        if image.size.width != 0 {
            collageImage = image
        }
    }
}

//
//  ThreeHorizantalViewController.swift
//  Snaptouch_Polaroid
//
//  Created by maximess120 on 26/02/18.
//  Copyright © 2018 maximess142. All rights reserved.
//

import UIKit 


class ThreeHorizantalViewController: BaseViewController {
    
    @IBOutlet weak var imageScrollViewTop: ZoomImageView!
    @IBOutlet weak var imageScrollViewBottom: ZoomImageView!
    @IBOutlet weak var imageScrollViewMiddle: ZoomImageView!
    
    @IBOutlet weak var collageBackgroundView: UIView!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var middleView: UIView!
    
    @IBOutlet weak var topViewConstraintHeight: NSLayoutConstraint!
    @IBOutlet weak var bottomViewConstraintHeight: NSLayoutConstraint!
    @IBOutlet weak var middleViewConstraintHeight: NSLayoutConstraint!
    
    @IBOutlet weak var sepratorTopIndicatorConstraintBottom: NSLayoutConstraint!
    @IBOutlet weak var sepratorTopIndicatorView: UIView!
    
    @IBOutlet weak var sepratorBottomIndicatorConstraintBottom: NSLayoutConstraint!
    @IBOutlet weak var sepratorBottomIndicatorView: UIView!
    
    
    var isSepratorAvailable = false
    var selImgArray = [UIImage]()
    var selectedTilesNumber = Int()
    var editViewModel = CAEditViewModel()

    fileprivate func loadUI() {
        // Do any additional setup after loading the view.
        imageScrollViewArray = [imageScrollViewTop,
                                    imageScrollViewMiddle,imageScrollViewBottom]
        
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(ThreeHorizantalViewController.singleTapGestureRecognizer(_:)))
        let tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(ThreeHorizantalViewController.singleTapGestureRecognizer(_:)))
        let tapGesture3 = UITapGestureRecognizer(target: self, action: #selector(ThreeHorizantalViewController.singleTapGestureRecognizer(_:)))
        
        tapGesture1.numberOfTapsRequired = 1
        tapGesture2.numberOfTapsRequired = 1
        tapGesture3.numberOfTapsRequired = 1
        
        topView.addGestureRecognizer(tapGesture1)
        middleView.addGestureRecognizer(tapGesture2)
        bottomView.addGestureRecognizer(tapGesture3)
        
        self.setInitialConstraints()
        
        //Assign images to imageScrollView
        
        for i in 0..<selImgArray.count {
            if i < imageScrollViewArray.count{
                imageScrollViewArray[i].zoomMode = .fill
                imageScrollViewArray[i].image = selImgArray[i]
            }
        }
        
        //top separator
        sepratorTopIndicatorView.layer.cornerRadius = separatorIndicatorCornerRadius
        sepratorTopIndicatorView.layer.borderWidth = 0.5
        sepratorTopIndicatorView.layer.borderColor = UIColor.lightGray.cgColor
        
        //bottom separator
        sepratorBottomIndicatorView.layer.cornerRadius = separatorIndicatorCornerRadius
        sepratorBottomIndicatorView.layer.borderWidth = 0.5
        sepratorBottomIndicatorView.layer.borderColor = UIColor.lightGray.cgColor
        
        // add borders to collage background view
        collageBackgroundView.layer.borderWidth = collageTilesBorderWidth
        collageBackgroundView.layer.borderColor = UIColor.clear.cgColor
        
        // add borders to collage tiles
        topView.layer.borderWidth = collageTilesBorderWidth
        topView.layer.borderColor = UIColor.clear.cgColor
        
        middleView.layer.borderWidth = collageTilesBorderWidth
        middleView.layer.borderColor = UIColor.clear.cgColor
        
        bottomView.layer.borderWidth = collageTilesBorderWidth
        bottomView.layer.borderColor = UIColor.clear.cgColor
        
        self.initLongPressGesture()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        loadUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func viewWillAppear(_ animated: Bool) {
        //self.setLocalization(view: self.view)
        NotificationCenter.default.addObserver(self, selector: #selector(self.applyMirrorEffect(_:)), name: NSNotification.Name(rawValue: "ThreeHorizantalVCMirror"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.applyFlipEffect(_:)), name: NSNotification.Name(rawValue: "ThreeHorizantalVCFlip"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.applyBorderEffect(_:)), name: NSNotification.Name(rawValue: "ThreeHorizantalVCBorder"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.saveCollageImage(_:)), name: NSNotification.Name(rawValue: "ThreeHorizantalVCSaveImg"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.applyRotateEffect(_:)), name: NSNotification.Name(rawValue: "ThreeHorizantalVCRotate"), object: nil)
        
        self.addSepratorsToTiles()
        DispatchQueue.main.asyncAfter(deadline: when) {
            self.setInitialConstraints()
            self.updateTilesFrame()
            self.removeSepratorFromTiles()
        }
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
    }
    
    func initLongPressGesture()  {
        let longpress1 = UILongPressGestureRecognizer(target: self, action: #selector(ThreeHorizantalViewController.longPressGestureRecognized1(_:)))
        topView.addGestureRecognizer(longpress1)
        
        let longpress2 = UILongPressGestureRecognizer(target: self, action: #selector(ThreeHorizantalViewController.longPressGestureRecognized2(_:)))
        middleView.addGestureRecognizer(longpress2)
        
        let longpress3 = UILongPressGestureRecognizer(target: self, action: #selector(ThreeHorizantalViewController.longPressGestureRecognized3(_:)))
        bottomView.addGestureRecognizer(longpress3)
        
        
    }
    
    func removeSepratorFromTiles() {
        if separatorColor == UIColor.clear {
            self.updateTilesFrame()
            for ( view) in self.collageBackgroundView.subviews {
                if view is SeparatorView {
                    view.removeFromSuperview()
                    self.middleView.topAnchor.constraint(equalTo: topView.bottomAnchor).isActive = true
                }
            }
        }
    }
    
    func setInitialConstraints()  {
        var tilesHeight = CGFloat()
        tilesHeight = self.collageBackgroundView.frame.size.height / 3
        self.topViewConstraintHeight.constant = tilesHeight
        self.bottomViewConstraintHeight.constant = tilesHeight
        self.middleViewConstraintHeight.constant = tilesHeight
        self.topView.layoutIfNeeded()
        self.bottomView.layoutIfNeeded()
        self.middleView.layoutIfNeeded()
    }
    
    func updateTilesFrame()  {
        self.topViewConstraintHeight.constant = self.topView.frame.size.height
        self.bottomViewConstraintHeight.constant = self.bottomView.frame.size.height
        self.middleViewConstraintHeight.constant = self.middleView.frame.size.height
    }
    
    func addSepratorsToTiles()  {
        
        //vertical seprators
        SeparatorView.addSeparatorBetweenViews(separatorType: .horizontal, primaryView: topView, secondaryView: middleView, parentView: self.collageBackgroundView)
        
        SeparatorView.addSeparatorBetweenViews(separatorType: .horizontal, primaryView: middleView, secondaryView: bottomView, parentView: self.collageBackgroundView)
        
    }
    
    @objc func longPressGestureRecognized1(_ gestureRecognizer: UIGestureRecognizer) {
        
        let longPress = gestureRecognizer as! UILongPressGestureRecognizer
        let state = longPress.state
        let locationInView = longPress.location(in: self.collageBackgroundView)
        
        
        struct My {
            static var cellSnapshot : UIView? = nil
            static var cellIsAnimating : Bool = false
            static var cellNeedToShow : Bool = false
        }
        
        
        switch state {
        case UIGestureRecognizer.State.began:
            
            
            My.cellSnapshot  = self.snapshotOfCell(topView)
            
            var center = topView.center
            My.cellSnapshot!.center = center
            My.cellSnapshot!.alpha = 0.0
            self.collageBackgroundView.addSubview(My.cellSnapshot!)
            
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellIsAnimating = true
                My.cellSnapshot!.center = center
                My.cellSnapshot!.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
                My.cellSnapshot!.alpha = 0.98
            }, completion: { (finished) -> Void in
                if finished {
                    My.cellIsAnimating = false
                    if My.cellNeedToShow {
                        My.cellNeedToShow = false
                        UIView.animate(withDuration: 0.25, animations: { () -> Void in
                        })
                    }
                }
            })
            
            
        case UIGestureRecognizer.State.changed:
            if My.cellSnapshot != nil {
                var center = My.cellSnapshot!.center
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellSnapshot!.center = center
                
                
                if My.cellSnapshot!.center.x > (self.middleView.center.x - (self.middleView.frame.width/3)) && My.cellSnapshot!.center.x < (self.middleView.center.x + (self.middleView.frame.width/3)) && My.cellSnapshot!.center.y > (self.middleView.center.y - (self.middleView.frame.height/3)) && My.cellSnapshot!.center.y < (self.middleView.center.y + (self.middleView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewMiddle.image
                    let img2 = self.imageScrollViewTop.image
                    
                    self.imageScrollViewMiddle.image = img2
                    
                    self.imageScrollViewTop.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.bottomView.center.x - (self.bottomView.frame.width/3)) && My.cellSnapshot!.center.x < (self.bottomView.center.x + (self.bottomView.frame.width/3)) && My.cellSnapshot!.center.y > (self.bottomView.center.y - (self.bottomView.frame.height/3)) && My.cellSnapshot!.center.y < (self.bottomView.center.y + (self.bottomView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottom.image
                    let img2 = self.imageScrollViewTop.image
                    
                    self.imageScrollViewBottom.image = img2
                    self.imageScrollViewTop.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                
                
            }
            
        default:
            if My.cellSnapshot != nil {
                
                My.cellSnapshot!.removeFromSuperview()
                My.cellSnapshot = nil
            }
            
        }
        
    }
    
    @objc func longPressGestureRecognized2(_ gestureRecognizer: UIGestureRecognizer) {
        
        let longPress = gestureRecognizer as! UILongPressGestureRecognizer
        let state = longPress.state
        let locationInView = longPress.location(in: self.collageBackgroundView)
        
        
        struct My {
            static var cellSnapshot : UIView? = nil
            static var cellIsAnimating : Bool = false
            static var cellNeedToShow : Bool = false
        }
        
        
        switch state {
        case UIGestureRecognizer.State.began:
            
            
            My.cellSnapshot  = self.snapshotOfCell(middleView)
            
            var center = middleView.center
            My.cellSnapshot!.center = center
            My.cellSnapshot!.alpha = 0.0
            self.collageBackgroundView.addSubview(My.cellSnapshot!)
            
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellIsAnimating = true
                My.cellSnapshot!.center = center
                My.cellSnapshot!.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
                My.cellSnapshot!.alpha = 0.98
            }, completion: { (finished) -> Void in
                if finished {
                    My.cellIsAnimating = false
                    if My.cellNeedToShow {
                        My.cellNeedToShow = false
                        UIView.animate(withDuration: 0.25, animations: { () -> Void in
                        })
                    }
                }
            })
            
            
        case UIGestureRecognizer.State.changed:
            if My.cellSnapshot != nil {
                var center = My.cellSnapshot!.center
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellSnapshot!.center = center
                
                
                if My.cellSnapshot!.center.x > (self.topView.center.x - (self.topView.frame.width/3)) && My.cellSnapshot!.center.x < (self.topView.center.x + (self.topView.frame.width/3)) && My.cellSnapshot!.center.y > (self.topView.center.y - (self.topView.frame.height/3)) && My.cellSnapshot!.center.y < (self.topView.center.y + (self.topView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewTop.image
                    let img2 = self.imageScrollViewMiddle.image
                    
                    self.imageScrollViewTop.image = img2
                    
                    self.imageScrollViewMiddle.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.bottomView.center.x - (self.bottomView.frame.width/3)) && My.cellSnapshot!.center.x < (self.bottomView.center.x + (self.bottomView.frame.width/3)) && My.cellSnapshot!.center.y > (self.bottomView.center.y - (self.bottomView.frame.height/3)) && My.cellSnapshot!.center.y < (self.bottomView.center.y + (self.bottomView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottom.image
                    let img2 = self.imageScrollViewMiddle.image
                    
                    self.imageScrollViewBottom.image = img2
                    self.imageScrollViewMiddle.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                
                
                
            }
            
        default:
            if My.cellSnapshot != nil {
                My.cellSnapshot!.removeFromSuperview()
                My.cellSnapshot = nil
            }
        }
    }
    
    
    @objc func longPressGestureRecognized3(_ gestureRecognizer: UIGestureRecognizer) {
        
        let longPress = gestureRecognizer as! UILongPressGestureRecognizer
        let state = longPress.state
        let locationInView = longPress.location(in: self.collageBackgroundView)
        
        
        struct My {
            static var cellSnapshot : UIView? = nil
            static var cellIsAnimating : Bool = false
            static var cellNeedToShow : Bool = false
        }
        
        
        switch state {
        case UIGestureRecognizer.State.began:
            
            
            My.cellSnapshot  = self.snapshotOfCell(bottomView)
            
            var center = bottomView.center
            My.cellSnapshot!.center = center
            My.cellSnapshot!.alpha = 0.0
            self.collageBackgroundView.addSubview(My.cellSnapshot!)
            
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellIsAnimating = true
                My.cellSnapshot!.center = center
                My.cellSnapshot!.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
                My.cellSnapshot!.alpha = 0.98
            }, completion: { (finished) -> Void in
                if finished {
                    My.cellIsAnimating = false
                    if My.cellNeedToShow {
                        My.cellNeedToShow = false
                        UIView.animate(withDuration: 0.25, animations: { () -> Void in
                        })
                    }
                }
            })
            
            
        case UIGestureRecognizer.State.changed:
            if My.cellSnapshot != nil {
                var center = My.cellSnapshot!.center
                center.y = locationInView.y
                center.x = locationInView.x
                My.cellSnapshot!.center = center
                
                
                if My.cellSnapshot!.center.x > (self.topView.center.x - (self.topView.frame.width/3)) && My.cellSnapshot!.center.x < (self.topView.center.x + (self.topView.frame.width/3)) && My.cellSnapshot!.center.y > (self.topView.center.y - (self.topView.frame.height/3)) && My.cellSnapshot!.center.y < (self.topView.center.y + (self.topView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewTop.image
                    let img2 = self.imageScrollViewBottom.image
                    
                    self.imageScrollViewTop.image = img2
                    
                    self.imageScrollViewBottom.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
                    
                else if My.cellSnapshot!.center.x > (self.middleView.center.x - (self.middleView.frame.width/3)) && My.cellSnapshot!.center.x < (self.middleView.center.x + (self.middleView.frame.width/3)) && My.cellSnapshot!.center.y > (self.middleView.center.y - (self.middleView.frame.height/3)) && My.cellSnapshot!.center.y < (self.middleView.center.y + (self.middleView.frame.height/3))  {
                    
                    let img1 = self.imageScrollViewBottom.image
                    let img2 = self.imageScrollViewMiddle.image
                    
                    self.imageScrollViewBottom.image = img2
                    self.imageScrollViewMiddle.image = img1
                    
                    
                    My.cellSnapshot!.removeFromSuperview()
                    My.cellSnapshot = nil
                }
            }
            
        default:
            if My.cellSnapshot != nil {
                My.cellSnapshot!.removeFromSuperview()
                My.cellSnapshot = nil
            }
        }
    }
    
    func snapshotOfCell(_ inputView: UIView) -> UIView {
        UIGraphicsBeginImageContextWithOptions(inputView.bounds.size, false, 0.0)
        inputView.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        let cellSnapshot : UIView = UIImageView(image: image)
        cellSnapshot.layer.masksToBounds = false
        cellSnapshot.layer.cornerRadius = 0.0
        cellSnapshot.layer.shadowOffset = CGSize(width: -5.0, height: 0.0)
        cellSnapshot.layer.shadowRadius = 5.0
        cellSnapshot.layer.shadowOpacity = 0.4
        return cellSnapshot
    }
    
    
    @objc func singleTapGestureRecognizer(_ gestureRecognizer: UIGestureRecognizer) {
        let selectedViewTag = gestureRecognizer.view?.tag
        //print("selectedViewTag = \(selectedViewTag)")
        
        selectedCollageFrameIndexInEdit = selectedViewTag! - 1
        
        self.addBorderToSelectedTils(tag:selectedViewTag!)
        
        /*
        if isSepratorAvailable {
            
            isSepratorAvailable = false
            self.updateTilesFrame()
            self.removeSepratorFromTiles()
        }else{
            isSepratorAvailable = true
            self.addSepratorsToTiles()
        }
 */
        
    }
    
    func addBorderToSelectedTils(tag:Int)  {
        switch tag {
            
        case 1:
            
            self.sepratorTopIndicatorConstraintBottom.constant = 2
            if topView.layer.borderColor == collageTilesBorderColor{
                self.removeBorderOfTiles()
                self.removeSepratorFromTiles()
                topView.layer.borderColor = UIColor.clear.cgColor
                
                
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":0])
                
            }else{
                self.removeBorderOfTiles()
                topView.layer.borderColor = collageTilesBorderColor
                
                sepratorTopIndicatorView.isHidden = false
                if separatorColor == UIColor.clear
                {
                self.removeSepratorFromTiles()
                self.addSepratorsToTiles()
                }
                self.selectedTilesNumber = 1
                
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":1])
            }
            
        case 2:
            
            self.sepratorTopIndicatorConstraintBottom.constant = 5
            self.sepratorBottomIndicatorConstraintBottom.constant = 2
            
            if middleView.layer.borderColor == collageTilesBorderColor{
                self.removeBorderOfTiles()
                self.removeSepratorFromTiles()
                middleView.layer.borderColor = UIColor.clear.cgColor
                
                
                
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":0])
                
            }else{
                self.removeBorderOfTiles()
                middleView.layer.borderColor = collageTilesBorderColor
                sepratorTopIndicatorView.isHidden = false
                sepratorBottomIndicatorView.isHidden = false
                if separatorColor == UIColor.clear
                {
                self.removeSepratorFromTiles()
                self.addSepratorsToTiles()
                }
                self.selectedTilesNumber = 2
                
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":1])
            }
            
        case 3:
            
            self.sepratorBottomIndicatorConstraintBottom.constant = 5
            
            if bottomView.layer.borderColor == collageTilesBorderColor{
                self.removeBorderOfTiles()
                self.removeSepratorFromTiles()
                bottomView.layer.borderColor = UIColor.clear.cgColor
                
                
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":0])
                
            }else{
                self.removeBorderOfTiles()
                bottomView.layer.borderColor = collageTilesBorderColor
                sepratorBottomIndicatorView.isHidden = false
                if separatorColor == UIColor.clear
                {
                self.removeSepratorFromTiles()
                self.addSepratorsToTiles()
                }
                self.selectedTilesNumber = 3
                
                NotificationCenter.default.post(name: Notification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: ["selected":1])
            }
            
        default: break
        }
    }
    
    func removeBorderOfTiles()  {
        sepratorTopIndicatorView.isHidden = true
        sepratorBottomIndicatorView.isHidden = true
        
        topView.layer.borderColor = UIColor.clear.cgColor
        bottomView.layer.borderColor = UIColor.clear.cgColor
        middleView.layer.borderColor = UIColor.clear.cgColor
        self.selectedTilesNumber = 0
    }
    
    @objc func applyMirrorEffect(_ notification: NSNotification)
        
    {
        
        switch selectedTilesNumber {
        case 1:
            let img = self.imageScrollViewTop.image
            
            let flippedImage = self.setEffectOn(image:img!, effect:.mirror)
            
            self.imageScrollViewTop.image = flippedImage
            
        case 2:
            let img = self.imageScrollViewMiddle.image
            
            let flippedImage = self.setEffectOn(image:img!, effect:.mirror)
            
            self.imageScrollViewMiddle.image = flippedImage
            
        case 3:
            let img = self.imageScrollViewBottom.image
            
            let flippedImage = self.setEffectOn(image:img!, effect:.mirror)
            
            self.imageScrollViewBottom.image = flippedImage
            
        default: break
        }
    }
    
    @objc func applyFlipEffect(_ notification: NSNotification)
        
    {
        
        switch selectedTilesNumber {
        case 1:
            let img = self.imageScrollViewTop.image
            let flippedImage = self.setEffectOn(image:img!, effect:.flip)
            self.imageScrollViewTop.image = flippedImage
        case 2:
            let img = self.imageScrollViewMiddle.image
            let flippedImage = self.setEffectOn(image:img!, effect:.flip)
            self.imageScrollViewMiddle.image = flippedImage
        case 3:
            let img = self.imageScrollViewBottom.image
            let flippedImage = self.setEffectOn(image:img!, effect:.flip)
            self.imageScrollViewBottom.image = flippedImage
        default: break
            
            //print("error")
        }
    }
    
    @objc func applyRotateEffect(_ notification: NSNotification)
    {
        switch selectedTilesNumber {
        case 1:
            let img = self.imageScrollViewTop.image
            let flippedImage = self.setEffectOn(image:img!, effect:.rotate)
            self.imageScrollViewTop.image = flippedImage
        case 2:
            let img = self.imageScrollViewMiddle.image
            let flippedImage = self.setEffectOn(image:img!, effect:.rotate)
            self.imageScrollViewMiddle.image = flippedImage
        case 3:
            let img = self.imageScrollViewBottom.image
            let flippedImage = self.setEffectOn(image:img!, effect:.rotate)
            self.imageScrollViewBottom.image = flippedImage
        default: break
        }
    }
    
    @objc func applyBorderEffect(_ notification: NSNotification) {
        if separatorColor == UIColor.white{
            separatorColor = UIColor.clear
            collageBackgroundView.layer.borderColor = UIColor.clear.cgColor
            self.removeSepratorFromTiles()
            self.addSepratorsToTiles()
            
        } else {
            separatorColor = UIColor.white
            collageBackgroundView.layer.borderColor = UIColor.white.cgColor
            self.removeSepratorFromTiles()
            self.updateTilesFrame()
            for ( view) in self.collageBackgroundView.subviews {
                
                if view is SeparatorView {
                    view.removeFromSuperview()
                }
            }
            self.addSepratorsToTiles()
        }
        
    }
    
    @objc func saveCollageImage(_ notification: NSNotification) {
        self.updateTilesFrame()
        self.removeSepratorFromTiles()
        self.removeBorderOfTiles()
        //Crop image
        let renderer = UIGraphicsImageRenderer(size: self.collageBackgroundView.bounds.size)
        let image = renderer.image { ctx in
            self.collageBackgroundView.drawHierarchy(in: self.collageBackgroundView.bounds, afterScreenUpdates: true)
        }
        
        if image.size.width != 0 {
            collageImage = image
        }
    }
}

//
//  EditCollageViewController.swift
//  CAGlobalPhotoSDK
//
//  Created by Gurleen Singh on 11/8/23.
//

import UIKit 
import Photos

var selectedCollageFrameIndexInEdit = Int()
class EditCollageViewController: BaseViewController {
    // This outlet represents the width of collage layout
    @IBOutlet weak var layoutWidthConstraints: NSLayoutConstraint!
    // This outlet represents the height of collage layout
    @IBOutlet weak var layoutHeightConstraint: NSLayoutConstraint!
    // This outlet represents the view of collage layout
    @IBOutlet weak var layoutView: UIView!
    // This outlet represents the mirror button
    @IBOutlet weak var mirrorButton: UIButton!
    // This outlet represents the flip button
    @IBOutlet weak var flipButton: UIButton!
    // This outlet represents the height of collage layout
    @IBOutlet weak var layoutViewHeightConstraint: NSLayoutConstraint!
    // This outlet represents the width of collage layout
    @IBOutlet weak var layoutViewWidthConstraint: NSLayoutConstraint!
    
    var layoutIndex = Int()
    var selectedImageArray = [UIImage]()
    var allPhotos: PHFetchResult<PHAsset>!
    var selectedAssetsIDArray = [String]()
    var savedImageAssetIdentifier = String()
    var scrollPositionIndex = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.layoutViewHeightConstraint.constant = 500
        self.layoutViewWidthConstraint.constant = 333
        NotificationCenter.default.addObserver(self, selector: #selector(self.replaceCollage(_:)), name: NSNotification.Name(rawValue: "ReplaceCollage"), object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        separatorColor = UIColor.clear
        NotificationCenter.default.addObserver(self, selector: #selector(self.collageStileSelect(_:)), name: NSNotification.Name(rawValue: "EditCollageVcCollagestileSelect"), object: nil)
        self.disableMirrorFlipBtn()
        self.setVwLayoutOrientation()
        NotificationCenter.default.addObserver(self, selector: #selector(self.getAssetIdentifierAfterSave(notification:)), name: NSNotification.Name(rawValue: "getAssetIdentifierAfterSave"), object: nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        separatorColor = UIColor.clear
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "getAssetIdentifierAfterSave"), object: nil)
    }
    
    //MARK:- IBAction
    
    @IBAction func backBtnClicked(_ sender:UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func saveBtnClicked(_ sender:UIButton){
        switch layoutIndex {
        case 0:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "TwoVerticalVCSaveImg"), object: nil)
        case 1:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "TwoHorizantalVCSaveImg"), object: nil)
        case 2:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ThreeVerticalVCSaveImg"), object: nil)
        case 3:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ThreeHorizantalVCSaveImg"), object: nil)
        case 4:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "FourHorizantalVCSaveImg"), object: nil)
        case 5:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "FourVerticalVCSaveImg"), object: nil)
        default: break
        }
        
        let isHp500 = true
        if isHp500 {
            let controller = CustomPaperLengthViewController(nibName: CustomPaperLengthViewController.className, bundle: nil)
            controller.mediaImage = collageImage
            self.navigationController?.pushViewController(controller, animated: true)
            
        } else {
            // For Kodak and polaroid Zip
            /*
            let imageHeigth = collageImage.size.height
            let imageWidth = collageImage.size.width
            var isLandscape = false
            var bestFitRatioValue: CGFloat?
            if imageHeigth > imageWidth {
                //-- Portrait
                isLandscape = false
                bestFitRatioValue = round(((imageHeigth/imageWidth) * 2) * 10) / 10.0
            } else {
                //-- landscape
                isLandscape = true
                bestFitRatioValue = round(((imageWidth/imageHeigth) * 2) * 10) / 10.0
            }
            let controller = CAEditViewController(nibName: CAEditViewController.className, bundle: nil)
            controller.imageOrignal = collageImage
            controller.selectedRatioWith = bestFitRatioValue
            controller.isLandscape = isLandscape
            controller.isBlankCanvasRuler = false
            self.navigationController?.pushViewController(controller, animated: true)
             */
        }
    }
    
    
    @IBAction func borderBtnClicked(_ sender:UIButton) {
        switch layoutIndex {
        case 0:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "TwoVerticalVCBorder"), object: nil)
        case 1:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "TwoHorizantalVCBorder"), object: nil)
        case 2:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ThreeVerticalVCBorder"), object: nil)
        case 3:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ThreeHorizantalVCBorder"), object: nil)
        case 4:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "FourHorizantalVCBorder"), object: nil)
        case 5:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "FourVerticalVCBorder"), object: nil)
        default: break
        }
        
    }
    
    @IBAction func mirrorBtnClicked(_ sender:UIButton) {
        switch layoutIndex {
        case 0:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "TwoVerticalVCMirror"), object: nil)
        case 1:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "TwoHorizantalVCMirror"), object: nil)
        case 2:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ThreeVerticalVCMirror"), object: nil)
        case 3:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ThreeHorizantalVCMirror"), object: nil)
        case 4:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "FourHorizantalVCMirror"), object: nil)
        case 5:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "FourVerticalVCMirror"), object: nil)
        default: break
        }
    }
    
    @IBAction func flipBtnClicked(_ sender:UIButton){
        switch layoutIndex {
        case 0:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "TwoVerticalVCFlip"), object: nil)
        case 1:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "TwoHorizantalVCFlip"), object: nil)
        case 2:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ThreeVerticalVCFlip"), object: nil)
        case 3:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ThreeHorizantalVCFlip"), object: nil)
        case 4:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "FourHorizantalVCFlip"), object: nil)
        case 5:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "FourVerticalVCFlip"), object: nil)
        default: break
        }
    }
    
    @IBAction func replaceBtnClicked(_ sender:UIButton) {
        let vc = CreateCollageViewController(nibName: CreateCollageViewController.className, bundle: nil)
        vc.isReplace = true
        vc.allPhotos = allPhotos
        vc.selectedAssetsIDArray = selectedAssetsIDArray
        vc.selectedCollageLayoutIndex = layoutIndex
        vc.selectedCollageFrameIndex = selectedCollageFrameIndexInEdit
        selectedCollageFrameIndexInEdit = 0
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func RotateBtn(_ sender: Any) {
        switch layoutIndex {
        case 0:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "TwoVerticalVCRotate"), object: nil)
        case 1:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "TwoHorizantalVCRotate"), object: nil)
        case 2:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ThreeVerticalVCRotate"), object: nil)
        case 3:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ThreeHorizantalVCRotate"), object: nil)
        case 4:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "FourHorizantalVCRotate"), object: nil)
        case 5:
            NotificationCenter.default.post(name: Notification.Name(rawValue: "FourVerticalVCRotate"), object: nil)
        default: break
        }
    }
    
    func enableMirrorFlipBtn(){
        self.mirrorButton.isEnabled = true
        self.flipButton.isEnabled = true
    }
    
    func disableMirrorFlipBtn(){
        self.mirrorButton.isEnabled = false
        self.flipButton.isEnabled = false
    }
    
    func setVwLayoutOrientation(){
        let newHeight = (980 / 640) * (self.view.frame.size.width * 0.63)
        switch layoutIndex {
        case 0:
            self.landscape()
            let layoutVC = TwoVerticalViewController(nibName: "TwoVerticalViewController", bundle: nil)
            layoutVC.selImgArray = self.selectedImageArray
            self.addFramelayouts(layoutVc: layoutVC, size: CGSize(width: newHeight, height: self.view.frame.size.width * 0.63))
        case 1:
            self.portrait()
            let layoutVC = TwoHorizantalViewController(nibName: "TwoHorizantalViewController", bundle: nil)
            layoutVC.selImgArray = self.selectedImageArray
            layoutVC.superViewHeight = self.view.frame.size.width
            layoutVC.superViewWidth = self.view.frame.size.width * 0.68
            self.addFramelayouts(layoutVc: layoutVC, size: CGSize(width: self.view.frame.size.width * 0.63, height: newHeight))
        case 2:
            self.landscape()
            let layoutVC = ThreeVerticalViewController(nibName: "ThreeVerticalViewController", bundle: nil)
            layoutVC.selImgArray = self.selectedImageArray
            self.addFramelayouts(layoutVc: layoutVC, size: CGSize(width: newHeight, height: self.view.frame.size.width * 0.63))
        case 3:
            self.portrait()
            let layoutVC = ThreeHorizantalViewController(nibName: "ThreeHorizantalViewController", bundle: nil)
            layoutVC.selImgArray = self.selectedImageArray
            self.addFramelayouts(layoutVc: layoutVC, size: CGSize(width: self.view.frame.size.width * 0.63, height: newHeight))
        case 4:
            self.landscape()
            let layoutVC = FourHorizantalViewController(nibName: "FourHorizantalViewController", bundle: nil)
            layoutVC.selImgArray = self.selectedImageArray
            self.addFramelayouts(layoutVc: layoutVC, size: CGSize(width: newHeight, height: self.view.frame.size.width * 0.63))
        case 5:
            self.portrait()
            let layoutVC = FourVerticalViewController(nibName: "FourVerticalViewController", bundle: nil)
            layoutVC.selImgArray = self.selectedImageArray
            self.addFramelayouts(layoutVc: layoutVC, size: CGSize(width: self.view.frame.size.width * 0.63, height: newHeight))
        default: break
        }
    }
    
    func landscape()  {
        let newHeight = (980 / 640) * (self.view.frame.size.width * 0.63)
        self.layoutWidthConstraints.constant =  newHeight // 407
        self.layoutHeightConstraint.constant = self.view.frame.size.width * 0.63//0.63//0.68 251//
    }
    
    func portrait()  {
        let newHeight = (1280 / 816) * (self.view.frame.size.width * 0.63)
        if getCurrentIphone() == "5" {
            self.layoutWidthConstraints.constant = self.view.frame.size.width * 0.63 //333
            self.layoutHeightConstraint.constant = newHeight
        } else {
            self.layoutWidthConstraints.constant = 333// self.view.frame.size.width * 0.63 //33
            self.layoutHeightConstraint.constant = 500// newHeight
        }
    }
    
    func addFramelayouts(layoutVc:UIViewController, size:CGSize) {
        if (self.layoutView.viewWithTag(100) != nil) {
            if let layoutView = self.layoutView.viewWithTag(100) {
                layoutView.removeFromSuperview()
            }
        }
        layoutVc.view.tag = 100
        let point = CGPoint(x: self.layoutView.frame.width/2, y:  self.layoutView.frame.height/2)
        layoutVc.view.frame = CGRect(origin: point, size: size)
        layoutVc.view.center = point
        self.layoutView.addSubview(layoutVc.view)
        self.addChild(layoutVc)
        layoutVc.view.frame = self.layoutView.bounds
        layoutVc.didMove(toParent: self)
    }
    
    @objc func collageStileSelect(_ notification: NSNotification) {
        let dict = notification.object as! NSDictionary
        guard let selected = dict.object(forKey: "selected") as? Int else {
            return
        }
        if selected == 1 {
            self.enableMirrorFlipBtn()
        } else {
            self.disableMirrorFlipBtn()
        }
    }
    
    @objc func replaceCollage(_ notification: NSNotification) {
        let dict = notification.object as! NSDictionary
        guard let layoutIndexReplace = dict.object(forKey: "layoutIndex") as? Int else {
            return
        }
        guard let selImgArrayReplace = dict.object(forKey: "selImgArray") as? [UIImage] else {
            return
        }
        guard let fetchResultReplace = dict.object(forKey: "fetchResult") as? PHFetchResult<PHAsset> else {
            return
        }
        guard let selAssetsIdentifiersArrayReplace = dict.object(forKey: "selAssetsIdentifiersArray") as? [String] else {
            return
        }
        self.layoutIndex = layoutIndexReplace
        self.selectedImageArray = selImgArrayReplace
        self.allPhotos = fetchResultReplace
        self.selectedAssetsIDArray = selAssetsIdentifiersArrayReplace
    }
    
    @objc func getAssetIdentifierAfterSave(notification : Notification) {
        if let assetIdentifier = notification.object as? String {
            self.savedImageAssetIdentifier = assetIdentifier
        }
    }
}



//
//  CreateCollageViewModel.swift
//  CAGlobalPhotoSDK
//
//  Created by iOS Developer on 11/8/23.
//

import Photos
class CreateCollageViewModel: NSObject {
    override init() {
        super.init()
    }
}

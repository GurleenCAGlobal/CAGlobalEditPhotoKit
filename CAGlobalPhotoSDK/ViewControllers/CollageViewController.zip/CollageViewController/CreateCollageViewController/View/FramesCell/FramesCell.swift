//
//  FramesCell.swift
//  CAGlobalPhotoSDK
//
//  Created by Gurleen Singh on 11/8/23.
//

import UIKit

class FramesCell: UICollectionViewCell {
    @IBOutlet weak var frameImageView: UIImageView!
    
    func configure(with data: String, selectedData: String, isSelected: Bool) {
        self.frameImageView.image = UIImage.init(named: data)
        if isSelected {
            self.frameImageView.image = UIImage.init(named: selectedData)
        } else {
            self.frameImageView.image = UIImage.init(named: data)
        }
    }
}

//
//  SelectedPhotosCell.swift
//  CAGlobalPhotoSDK
//
//  Created by Gurleen Singh on 11/8/23.
//

import UIKit

class SelectedPhotosCell: UICollectionViewCell {
    @IBOutlet weak var collageImageView: UIImageView!
    @IBOutlet weak var selectedButton: UIButton!
    var representedAssetIdentifier: String!

    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
        roundedCorner(image: collageImageView)
    }

    override func layoutIfNeeded() {

    }
}

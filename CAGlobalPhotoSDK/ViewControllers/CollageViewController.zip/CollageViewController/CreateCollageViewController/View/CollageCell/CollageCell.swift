//
//  CollageCell.swift
//  CAGlobalPhotoSDK
//
//  Created by Gurleen Singh on 11/8/23.
//

import UIKit

class CollageCell: UICollectionViewCell {
    @IBOutlet weak var collageImageView: UIImageView!
    @IBOutlet weak var indexLabel: UILabel!
    
    func configure(with isSelected: Bool, value: Int) {
        if isSelected {
            self.collageImageView.backgroundColor = UIColor().hexStringToUIColor(hex: "#353DC7")
            self.collageImageView.borderColor = UIColor().hexStringToUIColor(hex: "#353DC7")
            self.indexLabel.backgroundColor = UIColor().hexStringToUIColor(hex: "#353DC7")
            self.indexLabel.borderColor = UIColor().hexStringToUIColor(hex: "#353DC7")
        } else {
            self.collageImageView.borderColor = UIColor.black
            self.collageImageView.backgroundColor = UIColor(red:0.2, green:0.2, blue:0.24, alpha:1)
            self.indexLabel.borderColor = UIColor.black
            self.indexLabel.backgroundColor = UIColor(red:0.2, green:0.2, blue:0.24, alpha:1)
        }
        self.indexLabel?.text = "\(value + 1)"
    }
}

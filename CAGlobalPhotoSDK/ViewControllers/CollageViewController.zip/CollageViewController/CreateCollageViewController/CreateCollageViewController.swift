//
//  CreateCollageViewController.swift
//  CAGlobalPhotoSDK
//
//  Created by Gurleen Singh on 11/8/23.
//

import UIKit
import Photos

class CreateCollageViewController: BaseViewController {
    
    // This outlet represents the Frames collection view
    @IBOutlet weak var frameCollectionView: UICollectionView!
    // This outlet represents the all photos collection view
    @IBOutlet weak var photoCollectionView: UICollectionView!
    // This outlet represents the collage collection view
    @IBOutlet weak var collageCollectionView: UICollectionView!
    // This outlet represents the title label
    @IBOutlet weak var titleLabel: UILabel!
    // This outlet represents the selected collage
    @IBOutlet weak var selectedLayoutLabel: UILabel!
    // This outlet represents the next button to navigate to next screen
    @IBOutlet weak var nextButton: UIButton!
    // This outlet represents the collage view
    @IBOutlet weak var layoutView: UIView!
    // This outlet represents the collage top constraints
    @IBOutlet weak var layoutViewTopConstraint: NSLayoutConstraint!
    // This outlet represents the collage height constraints
    @IBOutlet weak var collageCollectionviewHeightConstraint: NSLayoutConstraint!
    // This outlet represents the collage width constraints
    @IBOutlet weak var collageCollectionviewWidthConstraints: NSLayoutConstraint!
    
    private(set) var layoutImageArray = [String]()
    var selecetdLayoutImageArray = [String]()
    var selectedAssetsIDArray = [String]()
    let imageManager = PHCachingImageManager()
    var thumbnailSize: CGSize!
    fileprivate var previousPreheatRect = CGRect.zero
    var allPhotos: PHFetchResult<PHAsset>!    
    var selectedCollageLayoutIndex = 0
    var selectedCollageFrameIndex = 0
    var previousSelectedImageIndex = 0
    var isReplace = false
    let imageRequestOptions = PHImageRequestOptions()
    var selectedImageIndexPath = [IndexPath]()
    var selectedImageIndex = Int()
    var socialPhotoURLArray = [String]()
    var createCollageViewModel = CreateCollageViewModel()
    private var collageLayoutManager = CollageLayoutManager()

    // MARK: - View Delegates
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.getDataForArray()
        self.registerCollectionCell()
        self.initialLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.setLayoutSize()
        // To reflect constraints changes immediately.
        self.view.layoutIfNeeded()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.scrollToSelectedArea()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getDataForArray() {
        self.layoutImageArray = self.collageLayoutManager.getCollageLayoutData()
        self.selecetdLayoutImageArray = self.collageLayoutManager.getSelectedCollageLayoutData()
    }
    
    func registerCollectionCell() {
        //Register Collection view cell
        let nibFrame = UINib(nibName: FramesCell.className, bundle: nil)
        self.frameCollectionView.register(nibFrame, forCellWithReuseIdentifier: FramesCell.className)
        self.frameCollectionView.delegate = self
        self.frameCollectionView.dataSource = self
        
        let nibCollage = UINib(nibName: CollageCell.className, bundle: nil)
        self.collageCollectionView.register(nibCollage, forCellWithReuseIdentifier: CollageCell.className)
        self.collageCollectionView.delegate = self
        self.collageCollectionView.dataSource = self

        let nibPhoto = UINib(nibName: SelectedPhotosCell.className, bundle: nil)
        self.photoCollectionView.register(nibPhoto, forCellWithReuseIdentifier: SelectedPhotosCell.className)
        self.photoCollectionView.delegate = self
        self.photoCollectionView.dataSource = self
    }
    
    func initialLoad() {
        if !isShowingSocialPhotos {
            self.getAssetsCollection()
        } else {
            if isSortByOldestFirst {
                socialPhotoURLArray = socialPhotoArray.reversed()
            } else {
                socialPhotoURLArray = socialPhotoArray
            }
        }
        // Make the count 6 so that when user clicks on layout with greater number, It would not crash
        while selectedAssetsIDArray.count != 6 {
            self.selectedAssetsIDArray.append("")
        }
        self.updateNextButtonStatus()
        self.replaceImage()
        // Allow to download image from iCloud
        imageRequestOptions.isNetworkAccessAllowed = true
    }
    
    func replaceImage() {
        if isReplace {
            self.titleLabel.text = "REPLACE PHOTO".localisedString()
            self.layoutViewTopConstraint.constant = -10
            self.frameCollectionView.isHidden = true
            self.selectedLayoutLabel.isHidden = true
        }
    }
    
    func setLayoutSize() {
        // Set the sizes for frame layout at the start.
        if self.selectedCollageLayoutIndex == 1 || self.selectedCollageLayoutIndex == 3 || self.selectedCollageLayoutIndex == 5 {
            self.collageCollectionviewHeightConstraint.constant = 180
            self.collageCollectionviewWidthConstraints.constant = 140
        } else {
            self.collageCollectionviewHeightConstraint.constant = 180
            self.collageCollectionviewWidthConstraints.constant = 268
        }
        
        self.frameCollectionView.reloadData()
        self.collageCollectionView.reloadData()
    }
    
    func scrollToSelectedArea() {
        self.scrollToSelectedImage()
        photoCollectionView.reloadData()
    }
    
    func scrollToSelectedImage() {
        self.photoCollectionView.scrollToItem(at: NSIndexPath(item: selectedImageIndex, section: 0) as IndexPath, at: .top, animated: false)
    }
    
    // MARK: - Fetching Photos
    func getAssetsCollection(){
        PHPhotoLibrary.shared().register(self)
        resetCachedAssets()
        // Determine the size of the thumbnails to request from the PHCachingImageManager
        thumbnailSize = CGSize(width:200, height: 200)
    }
    
    func updateNextButtonStatus() {
        self.nextButton.isHidden = true
        if selectedCollageLayoutIndex == 0 || selectedCollageLayoutIndex == 1 {
            if selectedAssetsIDArray[0] != "" && selectedAssetsIDArray[1] != "" {
                self.nextButton.isHidden = false
            }
        } else if selectedCollageLayoutIndex == 2 || selectedCollageLayoutIndex == 3 {
            if selectedAssetsIDArray[0] != "" && selectedAssetsIDArray[1] != "" && selectedAssetsIDArray[2] != "" {
                self.nextButton.isHidden = false
            }
        } else if selectedCollageLayoutIndex == 4 || selectedCollageLayoutIndex == 5 {
            if selectedAssetsIDArray[0] != "" && selectedAssetsIDArray[1] != "" && selectedAssetsIDArray[2] != "" && selectedAssetsIDArray[3] != "" {
                self.nextButton.isHidden = false
            }
        }
    }
    
    func getSelectedImageAssetBySelectedOrder(index : Int) -> PHAsset {
        // This condition is for oldest and newest first function
        var asset = PHAsset()
        if isSortByOldestFirst {
            asset = allPhotos.object(at: index)
        } else {
            asset = allPhotos.object(at: allPhotos.count - (index + 1))
        }
        return asset
    }

    // MARK: UIScrollView
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        updateCachedAssets()
    }
    
    // MARK: Asset Caching
    
    fileprivate func resetCachedAssets() {
        imageManager.stopCachingImagesForAllAssets()
        previousPreheatRect = .zero
    }
    
    fileprivate func updateCachedAssets() {
        if isShowingSocialPhotos == false {
            // Update only if the view is visible.
            guard isViewLoaded && view.window != nil else { return }
            // The preheat window is twice the height of the visible rect.
            let visibleRect = CGRect(origin: photoCollectionView!.contentOffset, size: photoCollectionView!.bounds.size)
            let preheatRect = visibleRect.insetBy(dx: 0, dy: -0.5 * visibleRect.height)
            
            // Update only if the visible area is significantly different from the last preheated area.
            let delta = abs(preheatRect.midY - previousPreheatRect.midY)
            guard delta > view.bounds.height / 3 else { return }
            // Compute the assets to start caching and to stop caching.
            let (addedRects, removedRects) = differencesBetweenRects(previousPreheatRect, preheatRect)
            let addedAssets = addedRects
                .flatMap { rect in photoCollectionView!.indexPathsForElements(in: rect) }
                .map { indexPath in allPhotos.object(at: indexPath.item) }
            let removedAssets = removedRects
                .flatMap { rect in photoCollectionView!.indexPathsForElements(in: rect) }
                .map { indexPath in allPhotos.object(at: indexPath.item) }
            // Update the assets the PHCachingImageManager is caching.
            imageManager.startCachingImages(for: addedAssets,
                                            targetSize: thumbnailSize, contentMode: .aspectFill, options: nil)
            imageManager.stopCachingImages(for: removedAssets,
                                           targetSize: thumbnailSize, contentMode: .aspectFill, options: nil)
            // Store the preheat rect to compare against in the future.
            previousPreheatRect = preheatRect
        }
    }
    
    //MARK:- Button Actions
    
    @IBAction func backBtnClicked(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func nextBtnClicked(_ sender: UIButton) {
        let controller = EditCollageViewController(nibName: EditCollageViewController.className, bundle: nil)
        controller.layoutIndex = selectedCollageLayoutIndex
        var selImgArray = [UIImage]()
        if !isShowingSocialPhotos {
            selImgArray = self.getImagesFromAssets(selectedAssetsIDArray: self.selectedAssetsIDArray)
        }
        controller.selectedImageArray = selImgArray
        // Pass fetchresult so that when we come from replace screen we have same set of images to show
        controller.allPhotos = allPhotos
        controller.selectedAssetsIDArray = selectedAssetsIDArray
        controller.scrollPositionIndex = selectedImageIndex
        let dict = ["layoutIndex":selectedCollageLayoutIndex,"selImgArray":selImgArray,"fetchResult":allPhotos ?? [],"selAssetsIdentifiersArray":selectedAssetsIDArray] as [String : Any]
        if isReplace {
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ReplaceCollage"), object: dict)
            self.navigationController?.popViewController(animated: true)
        } else {
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
}

// MARK: - PHPhotoLibraryChangeObserver
extension CreateCollageViewController: PHPhotoLibraryChangeObserver {
    
    func photoLibraryDidChange(_ changeInstance: PHChange) {
        guard changeInstance.changeDetails(for: allPhotos) != nil
        else { return }
        // Change notifications may be made on a background queue. Re-dispatch to the
        // Main queue before acting on the change as we'll be updating the UI.
        DispatchQueue.main.sync {
            // Hang on to the new fetch result.
            self.getAssetsCollection()
            self.photoCollectionView.reloadData()
            self.resetCachedAssets()
        }
    }
}

// MARK: - UICollection Views delegate and data sources
extension CreateCollageViewController:UICollectionViewDelegate,UICollectionViewDataSource {
    func updateSelectedIndex(indexPath:IndexPath) {
        if !selectedImageIndexPath.contains(indexPath) {
            selectedImageIndexPath.append(indexPath)
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch collectionView {
        case frameCollectionView:
            return self.layoutImageArray.count
        case photoCollectionView:
            if isShowingSocialPhotos {
                return self.socialPhotoURLArray.count
            } else {
                return self.allPhotos.count
            }
        case collageCollectionView:
            switch selectedCollageLayoutIndex {
            case 0:
                return 2
            case 1:
                return 2
            case 2:
                return 3
            case 3:
                return 3
            case 4:
                return 4
            case 5:
                return 4
            default: break
            }
        default: break
        }
        
        return 0
    }
    
    fileprivate func getImageFromAsset(_ indexPath: IndexPath, _ item: CollageCell) {
        let identifier = self.selectedAssetsIDArray[indexPath.item]
        if identifier != "" {
            item.collageImageView.isHidden = false
            let assetsFetchResult = PHAsset.fetchAssets(withLocalIdentifiers: [identifier], options: nil)
            assetsFetchResult.enumerateObjects{(object: AnyObject!,
                                                count: Int,
                                                stop: UnsafeMutablePointer<ObjCBool>) in
                if object is PHAsset{
                    let asset = object as! PHAsset
                    let imageSize = CGSize(width: asset.pixelWidth,
                                           height: asset.pixelHeight)
                    self.imageManager.requestImage(for: asset, targetSize: imageSize, contentMode: .aspectFill, options: nil, resultHandler: { image, _ in if let image = image {
                        item.collageImageView.image = image
                        self.updateNextButtonStatus()
                    }
                    })
                }
            }
        } else {
            item.collageImageView.isHidden = true
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.frameCollectionView {
            
            let cell : FramesCell = collectionView.dequeueReusableCell(withReuseIdentifier: FramesCell.className, for: indexPath) as! FramesCell
            cell.configure(with: layoutImageArray[indexPath.row], selectedData: selecetdLayoutImageArray[indexPath.row], isSelected: selectedCollageLayoutIndex == indexPath.row)
            return cell
            
        } else if collectionView == photoCollectionView {
            let cell : SelectedPhotosCell = collectionView.dequeueReusableCell(withReuseIdentifier: SelectedPhotosCell.className, for: indexPath) as! SelectedPhotosCell
            
                 let asset = getSelectedImageAssetBySelectedOrder(index: indexPath.item)
                // Request an image for the asset from the PHCachingImageManager.
                imageManager.requestImage(for: asset, targetSize: thumbnailSize, contentMode: .aspectFill, options: imageRequestOptions, resultHandler: { image, _ in
                    if let image = image {
                        cell.collageImageView.image = image
                    }
                })
                
                let assetId = asset.localIdentifier
                cell.representedAssetIdentifier = assetId
                if self.selectedAssetsIDArray.contains(cell.representedAssetIdentifier){
                    cell.selectedButton.isSelected = true
                    self.updateSelectedIndex(indexPath: indexPath)
                } else {
                    cell.selectedButton.isSelected = false
                }
            return cell
        } else {
            let cell : CollageCell = collectionView.dequeueReusableCell(withReuseIdentifier: CollageCell.className, for: indexPath) as! CollageCell
            cell.configure(with: indexPath.item == selectedCollageFrameIndex,value: indexPath.item)
            self.getImageFromAsset(indexPath, cell)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.frameCollectionView {
            self.selectedCollageLayoutIndex = indexPath.row
            if indexPath.row == 1 || indexPath.row == 3 || indexPath.row == 5 {
                self.collageCollectionviewHeightConstraint.constant = 180
                self.collageCollectionviewWidthConstraints.constant = 140
            } else {
                self.collageCollectionviewHeightConstraint.constant = 180
                self.collageCollectionviewWidthConstraints.constant = 268
            }
            self.frameCollectionView.reloadData()
            self.collageCollectionView.reloadData()
            // To reflect constraints changes immediately.
            self.view.layoutIfNeeded()
        } else if collectionView == self.collageCollectionView {
            self.selectedCollageFrameIndex = indexPath.row
            if previousSelectedImageIndex != indexPath.row {
                self.collageCollectionView.reloadItems(at: [IndexPath(row: previousSelectedImageIndex, section: indexPath.section), IndexPath(row: selectedCollageFrameIndex, section: indexPath.section)])
            }
            previousSelectedImageIndex = selectedCollageFrameIndex
        } else {
            var localIdentifier = String()
            if isShowingSocialPhotos  {
                localIdentifier = socialPhotoURLArray[indexPath.row]
            } else {
                let asset = getSelectedImageAssetBySelectedOrder(index: indexPath.item)
                localIdentifier = asset.localIdentifier//fetchResult[indexPath.item].localIdentifier
            }
            if self.selectedAssetsIDArray.contains(localIdentifier) {
                let index = self.selectedAssetsIDArray.firstIndex(of: localIdentifier)
                if index == selectedCollageFrameIndex {
                    self.selectedAssetsIDArray[index!] = ""
                }
            } else {
                selectedImageIndexPath.append(indexPath)
                self.selectedAssetsIDArray[selectedCollageFrameIndex] = localIdentifier
                if selectedCollageFrameIndex == 0 {
                    selectedImageIndex = indexPath.row
                }
            }
            DispatchQueue.main.async {
                self.collageCollectionView.reloadItems(at: [IndexPath(item: self.selectedCollageFrameIndex, section: 0)])
                self.updateSelectedIndex(indexPath: indexPath)
                self.photoCollectionView.reloadItems(at:self.selectedImageIndexPath)
                if self.selectedImageIndexPath.count > 20 {
                    self.selectedImageIndexPath.removeAll()
                    self.photoCollectionView.reloadData()
                }
            }
        }        
        self.updateNextButtonStatus()
    }
}

extension CreateCollageViewController : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch collectionView {
        case frameCollectionView:
            return CGSize(width: 25, height: 25)
        case photoCollectionView:
            let flowLayout = collectionViewLayout as! UICollectionViewFlowLayout
            let totalSpace = flowLayout.sectionInset.left + flowLayout.sectionInset.right + (flowLayout.minimumInteritemSpacing)
            let size = Int((collectionView.bounds.width - totalSpace) / CGFloat(4))
            return CGSize(width: size-10, height: size-10)
        case collageCollectionView:
            switch selectedCollageLayoutIndex {
            case 0:
                return CGSize(width: collageCollectionView.bounds.size.width/2, height: collageCollectionView.bounds.size.height)
            case 1:
                return CGSize(width: collageCollectionView.bounds.size.width, height: collageCollectionView.bounds.size.height/2)
            case 2:
                return CGSize(width: collageCollectionView.bounds.size.width/3, height: collageCollectionView.bounds.size.height)
            case 3:
                return CGSize(width: collageCollectionView.bounds.size.width, height: collageCollectionView.bounds.size.height/3)
            case 4:
                return CGSize(width: collageCollectionView.bounds.size.width/2, height: collageCollectionView.bounds.size.height/2)
            case 5:
                return CGSize(width: collageCollectionView.bounds.size.width/2, height: collageCollectionView.bounds.size.height/2)
            default: break
            }
        default: break
        }
        return CGSize(width: 0, height: 0)
    }
}

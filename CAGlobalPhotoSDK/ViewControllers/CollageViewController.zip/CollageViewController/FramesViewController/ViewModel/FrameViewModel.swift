//
//  FrameViewModel.swift
//  CAGlobalPhotoSDK
//
//  Created by iOS Developer on 3/10/23.
//

import UIKit

class FrameViewModel: NSObject {

}

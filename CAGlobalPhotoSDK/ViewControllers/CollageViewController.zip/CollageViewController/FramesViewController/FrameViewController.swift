//
//  FrameViewController.swift
//  CAGlobalPhotoSDK
//
//  Created by Gurleen Singh on 11/8/23.
//

import UIKit
import Photos

class FrameViewController: BaseViewController {
    
    // This outlet represents the main view where we are showing image and textView
    @IBOutlet weak var mainView: UIView!
    // This outlet represents the horizontal button where we are 2 horizontal frames
    @IBOutlet weak var horizontal2Button: UIButton!
    // This outlet represents the horizontal button where we are 3 horizontal frames
    @IBOutlet weak var horizontal3Button: UIButton!
    // This outlet represents the horizontal button where we are 4 horizontal frames
    @IBOutlet weak var horizontal4Button: UIButton!
    // This outlet represents the vertical button where we are 2 horizontal frames
    @IBOutlet weak var vertical2Button: UIButton!
    // This outlet represents the vertical button where we are 3 horizontal frames
    @IBOutlet weak var vertical3Button: UIButton!
    // This outlet represents the vertical button where we are 4 horizontal frames
    @IBOutlet weak var vertical4Button: UIButton!
    
    var selectedAssetsIDArray = [String]()
    var allPhotos: PHFetchResult<PHAsset>!
    var selectedImageIndex = [Int]()
    var scrollViewContent = CGFloat()
    var scrollViewIndexCallBack : ((CGFloat) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        self.selectAllFrameLayoutButton()
        self.highlightSelectedFrameLayoutBtn()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    // MARK: - IBActions
    @IBAction func actionBackButton(_ sender: UIButton) {
        self.scrollViewIndexCallBack?(scrollViewContent)
        self.dismiss(animated: true)
    }
    
    fileprivate func selectedImageIndex(_ sender: UIButton, _ vc: CreateCollageViewController) {
        var index = 1
        if sender.tag == 3 || sender.tag == 4 {
            index = 2
        } else if sender.tag == 5 || sender.tag == 6 {
            index = 3
        }
        
        if index >= (selectedImageIndex.count - 1) {
            vc.selectedImageIndex = selectedImageIndex.last!
            vc.selectedCollageFrameIndex = selectedImageIndex.count - 1
        } else {
            vc.selectedImageIndex = selectedImageIndex[index]
            vc.selectedCollageFrameIndex = index
        }
    }
    
    @IBAction func actionFrameLayoutButton(_ sender: UIButton) {
        let vc = CreateCollageViewController(nibName: CreateCollageViewController.className, bundle: nil)
        vc.selectedCollageLayoutIndex = sender.tag - 1
        vc.selectedAssetsIDArray = self.selectedAssetsIDArray
        vc.allPhotos = allPhotos
        selectedImageIndex(sender, vc)
        selectedImagesData.removeAll()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    // MARK: - Functions
    func selectAllFrameLayoutButton()  {
        self.framesLayout(isHidden: false)
    }
    
    func highlightSelectedFrameLayoutBtn()  {
        switch self.selectedAssetsIDArray.count {
        case 1:
            self.framesLayout(isHidden: true)
        case 2:
            self.horizontal2Button.isSelected = true
            self.vertical2Button.isSelected = true
        case 3:
            self.horizontal3Button.isSelected = true
            self.vertical3Button.isSelected = true
        case 4:
            self.horizontal4Button.isSelected = true
            self.vertical4Button.isSelected = true
        default: break
        }
    }
    
    func framesLayout(isHidden: Bool) {
        self.horizontal2Button.isSelected = isHidden
        self.horizontal3Button.isSelected = isHidden
        self.horizontal4Button.isSelected = isHidden
        self.vertical2Button.isSelected = isHidden
        self.vertical3Button.isSelected = isHidden
        self.vertical4Button.isSelected = isHidden
    }
}
